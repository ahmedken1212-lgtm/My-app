package com.souq.sudan.data.model

data class Listing(
    val id: String,
    val title: String,
    val description: String,
    val priceSdg: Long,
    val isNegotiable: Boolean,
    val categoryId: String,
    val subCategory: String? = null,
    val city: String,
    val district: String? = null,
    val imageUrls: List<String>,
    val createdAt: String,
    val isFeatured: Boolean = false,
    val viewsCount: Int = 0,
    val sellerName: String,
    val sellerPhone: String,
    val sellerWhatsapp: String,
    val isSellerVerified: Boolean = false
)

data class Category(
    val id: String,
    val nameAr: String,
    val subcategories: List<String>,
    val listingsCount: Int
)
