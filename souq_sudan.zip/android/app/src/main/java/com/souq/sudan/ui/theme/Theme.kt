package com.souq.sudan.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = SudanDarkGreen,
    onPrimary = Color.White,
    primaryContainer = SudanGreenContainer,
    onPrimaryContainer = SudanOnGreenContainer,
    secondary = SudanAmberAccent,
    background = SudanBackground,
    surface = SudanSurface,
    surfaceVariant = SudanCardBorder
)

@Composable
fun SouqSudanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
