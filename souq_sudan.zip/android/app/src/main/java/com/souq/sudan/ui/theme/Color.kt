package com.souq.sudan.ui.theme

import androidx.compose.ui.graphics.Color

// Sudanese Market Material 3 Brand Identity
val SudanDarkGreen = Color(0xFF0D5C3A)
val SudanLightGreen = Color(0xFF1E824C)
val SudanGreenContainer = Color(0xFFA4F4C4)
val SudanOnGreenContainer = Color(0xFF002111)

val SudanAmberAccent = Color(0xFFF59E0B)
val SudanSurface = Color(0xFFFFFFFF)
val SudanBackground = Color(0xFFF8FAF9)
val SudanCardBorder = Color(0xFFE2E8F0)
val SudanTextPrimary = Color(0xFF0F172A)
val SudanTextSecondary = Color(0xFF64748B)
