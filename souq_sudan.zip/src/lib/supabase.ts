import { createClient, SupabaseClient, User, Session } from '@supabase/supabase-js';

// Read config from Vite environment variables or localStorage (for dynamic key input if needed)
const defaultUrl = 'https://dxkconlzpswrubhsfbhz.supabase.co';
const envUrl = import.meta.env.VITE_SUPABASE_URL;
const envAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const SUPABASE_URL = (envUrl && envUrl.trim() !== '') ? envUrl.trim() : defaultUrl;

export const sanitizeKey = (k: string): string => {
  let cleaned = k.trim();
  if ((cleaned.startsWith('"') && cleaned.endsWith('"')) || (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
    cleaned = cleaned.slice(1, -1).trim();
  }
  if (cleaned.toLowerCase().startsWith('bearer ')) {
    cleaned = cleaned.slice(7).trim();
  }
  return cleaned;
};

export const getSupabaseAnonKey = (): string => {
  if (envAnonKey && envAnonKey.trim() !== '' && envAnonKey !== 'your-anon-publishable-key-here') {
    return sanitizeKey(envAnonKey);
  }
  // Fallback to localStorage if the user entered it via in-app config
  try {
    const saved = localStorage.getItem('sudan_souq_supabase_anon_key');
    if (saved && saved.trim() !== '') return sanitizeKey(saved);
  } catch (e) {
    // ignore
  }
  return '';
};

export const setSupabaseAnonKey = (key: string) => {
  try {
    const cleaned = sanitizeKey(key);
    localStorage.setItem('sudan_souq_supabase_anon_key', cleaned);
    // Reload or re-instantiate client
    initClient();
  } catch (e) {
    // ignore
  }
};

let clientInstance: SupabaseClient | null = null;

const initClient = (): SupabaseClient | null => {
  const key = getSupabaseAnonKey();
  if (!key || key.length < 10) {
    clientInstance = null;
    return null;
  }
  try {
    clientInstance = createClient(SUPABASE_URL, key, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return clientInstance;
  } catch (err) {
    console.error('Failed to initialize Supabase client:', err);
    clientInstance = null;
    return null;
  }
};

export const getSupabaseClient = (): SupabaseClient | null => {
  if (!clientInstance) {
    return initClient();
  }
  return clientInstance;
};

export const isSupabaseConfigured = (): boolean => {
  const key = getSupabaseAnonKey();
  return Boolean(SUPABASE_URL && key && key.length >= 10);
};

/**
 * Translate Supabase Auth errors to helpful Arabic user messages
 */
export const translateSupabaseAuthError = (err: any): string => {
  if (!err) return '';
  const msg = (typeof err === 'string' ? err : err.message || err.error_description || '').toLowerCase();

  if (msg.includes('rate limit') || msg.includes('over_email_send_rate_limit')) {
    return 'تم تجاوز الحد المسموح به مؤقتاً لإرسال رسائل البريد الإلكتروني في مشروع Supabase (Rate limit). يرجى الانتظار بضع دقائق قبل إعادة المحاولة، أو تعطيل خيار "Confirm email" في لوحة تحكم Supabase لتفعيل التسجيل الفوري.';
  }
  if (msg.includes('user already registered') || msg.includes('already exists')) {
    return 'هذا البريد الإلكتروني مسجل مسبقاً في النظام. يمكنك الانتقال مباشرة إلى صفحة تسجيل الدخول.';
  }
  if (msg.includes('password') && (msg.includes('least') || msg.includes('short') || msg.includes('weak'))) {
    return 'كلمة المرور قصيرة أو غير مقبولة. يجب أن تتكون من 6 خانات على الأقل.';
  }
  if (msg.includes('invalid login credentials') || msg.includes('invalid credentials')) {
    return 'بيانات الدخول غير صحيحة. يرجى التحقق من البريد الإلكتروني وكلمة المرور.';
  }
  if (msg.includes('invalid email') || msg.includes('valid email') || msg.includes('unable to validate email')) {
    return 'صيغة البريد الإلكتروني غير صحيحة. يرجى إدخال بريد إلكتروني صالح مثل name@example.com.';
  }
  if (msg.includes('email not confirmed')) {
    return 'لم يتم تأكيد البريد الإلكتروني بعد. يرجى مراجعة صندوق الوارد في بريدك، أو تعطيل خيار "Confirm email" في إعدادات Supabase لتخطي التأكيد.';
  }
  if (msg.includes('network') || msg.includes('failed to fetch')) {
    return 'تعذر الاتصال بخادم Supabase. يرجى التحقق من اتصال الإنترنت.';
  }

  return err.message || 'حدث خطأ في عملية المصادقة. يرجى مراجعة البيانات والمحاولة مجدداً.';
};

// Database listing schema mapping strictly matching public.listings:
// Columns: id, seller_id, title, description, price, category, city, image_urls, status, created_at, updated_at
export interface DbListingRow {
  id: string;
  seller_id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  city: string;
  image_urls?: string[];
  status?: string;
  created_at: string;
  updated_at?: string;

  // Optional parsed or legacy fields for app compatibility
  category_id?: string;
  sub_category?: string;
  district?: string;
  is_negotiable?: boolean;
  seller_name?: string;
  seller_phone?: string;
  seller_whatsapp?: string;
  seller_verified?: boolean;
  views_count?: number;
  featured?: boolean;
  attributes?: Record<string, any>;
  images?: string[];
}

export interface CreateListingPayload {
  title: string;
  description: string;
  price: number;
  category?: string;
  category_id?: string;
  city: string;
  image_urls?: string[];
  status?: string;

  // Extra form attributes that are converted into description and metadata
  sub_category?: string;
  district?: string;
  is_negotiable?: boolean;
  seller_phone?: string;
  seller_whatsapp?: string;
  attributes?: Record<string, any>;
  preset_image_urls?: string[];
}

/**
 * Fetch all listings from public.listings
 */
export const fetchDbListings = async (): Promise<{ data: DbListingRow[] | null; error: any }> => {
  const client = getSupabaseClient();
  if (!client) {
    return { data: null, error: new Error('Supabase is not configured yet. Anon key is required.') };
  }

  try {
    const { data, error } = await client
      .from('listings')
      .select('*')
      .order('created_at', { ascending: false });

    return { data, error };
  } catch (err: any) {
    return { data: null, error: err };
  }
};

/**
 * Insert a new listing into public.listings
 * Strictly conforms to public.listings columns:
 * - id, seller_id, title, description, price, category, city, image_urls, status, created_at, updated_at
 * DOES NOT send unmapped columns (like attributes, category_id, sub_category, district, etc.) to prevent schema cache errors.
 * Preserves extra attributes (e.g. sub_category, district, is_negotiable, contact info) inside description and metadata.
 * Ensures seller_id is strictly bound to the authenticated user ID from Supabase Auth session.
 */
export const insertDbListing = async (
  payload: CreateListingPayload,
  user: User
): Promise<{ data: DbListingRow | null; error: any }> => {
  const client = getSupabaseClient();
  if (!client) {
    return { data: null, error: new Error('Supabase client is not initialized.') };
  }

  try {
    // 1. Enforce seller_id strictly from authenticated session
    const currentUserId = user?.id || (await client.auth.getUser()).data?.user?.id;
    if (!currentUserId) {
      return { data: null, error: new Error('يجب تسجيل الدخول بحساب موثق أولاً لنشر إعلان في قاعدة البيانات.') };
    }

    // 2. Format extra attributes safely into description so no user data is lost
    const extraSections: string[] = [];
    const metaPayload: Record<string, any> = {};

    if (payload.sub_category) {
      extraSections.push(`• القسم الفرعي: ${payload.sub_category}`);
      metaPayload.subCategory = payload.sub_category;
    }
    if (payload.district) {
      extraSections.push(`• الحي / المنطقة: ${payload.district}`);
      metaPayload.district = payload.district;
    }
    if (payload.is_negotiable !== undefined) {
      extraSections.push(`• حالة السعر: ${payload.is_negotiable ? 'قابل للتفاوض' : 'السعر نهائي'}`);
      metaPayload.isNegotiable = payload.is_negotiable;
    }
    if (payload.seller_phone) {
      extraSections.push(`• هاتف التواصل: ${payload.seller_phone}`);
      metaPayload.phone = payload.seller_phone;
    }
    if (payload.seller_whatsapp) {
      metaPayload.whatsapp = payload.seller_whatsapp;
    }
    if (payload.attributes && Object.keys(payload.attributes).length > 0) {
      for (const [key, val] of Object.entries(payload.attributes)) {
        if (val) {
          extraSections.push(`• ${key}: ${val}`);
        }
      }
      metaPayload.attributes = payload.attributes;
    }

    let finalDescription = (payload.description || '').trim();
    if (extraSections.length > 0) {
      finalDescription += `\n\n📌 مواصفات وتفاصيل إضافية:\n${extraSections.join('\n')}`;
    }

    // Embed compact metadata comment for 100% loss-free extraction
    if (Object.keys(metaPayload).length > 0) {
      finalDescription += `\n<!--metadata:${JSON.stringify(metaPayload)}-->`;
    }

    // 3. Category: column in DB is 'category'
    const categoryValue = payload.category || payload.category_id || 'cars';

    // 4. Strict row containing ONLY valid columns of public.listings:
    // id, seller_id, title, description, price, category, city, image_urls, status
    const rowToInsert: Record<string, any> = {
      seller_id: currentUserId,
      title: payload.title.trim(),
      description: finalDescription,
      price: Number(payload.price),
      category: categoryValue,
      city: payload.city,
      image_urls: payload.image_urls || [],
      status: payload.status || 'active',
    };

    const { data, error } = await client
      .from('listings')
      .insert(rowToInsert)
      .select()
      .single();

    return { data, error };
  } catch (err: any) {
    return { data: null, error: err };
  }
};

/**
 * Upload an image file to Supabase Storage bucket 'listing-images'
 * and retrieve its public URL.
 */
export const uploadListingImage = async (
  file: File,
  userId: string
): Promise<{ publicUrl: string | null; error: any }> => {
  const client = getSupabaseClient();
  if (!client) {
    return { publicUrl: null, error: new Error('Supabase client is not initialized.') };
  }

  try {
    // Generate unique sanitized filename
    const fileExt = file.name.split('.').pop() || 'jpg';
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, '');
    const fileName = `${userId}/${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${cleanExt}`;

    const { data, error: uploadError } = await client.storage
      .from('listing-images')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      return { publicUrl: null, error: uploadError };
    }

    // Get public URL
    const { data: urlData } = client.storage
      .from('listing-images')
      .getPublicUrl(data.path);

    return { publicUrl: urlData.publicUrl, error: null };
  } catch (err: any) {
    return { publicUrl: null, error: err };
  }
};
