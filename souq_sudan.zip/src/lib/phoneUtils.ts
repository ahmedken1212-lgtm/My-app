/**
 * Phone Number Validation & Formatting Utilities for Sudan Souq
 * Handles Sudanese phone numbers (+249) and international formats.
 */

export interface PhoneValidationResult {
  isValid: boolean;
  raw: string;
  international: string;   // e.g. +249912345678
  local: string;           // e.g. 0912345678
  whatsapp: string;        // e.g. 249912345678 (digits only)
  errorAr?: string;
  errorEn?: string;
}

/**
 * Normalizes Eastern Arabic (Arabic-Indic) numerals to Western digits.
 */
export const normalizeArabicDigits = (str: string): string => {
  const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return str.replace(/[٠-٩]/g, (w) => arabicNumerals.indexOf(w).toString());
};

/**
 * Validates and standardizes a Sudanese phone number.
 * Supported Sudanese mobile networks:
 * - Zain: 090, 091, 092, 096, 099 -> 9 digits after 249 starting with 9
 * - MTN: 092, 093, 099 -> 9 digits after 249 starting with 9
 * - Sudani: 010, 011, 012 -> 9 digits after 249 starting with 1
 *
 * Valid inputs examples:
 * - 0912345678
 * - 0123456789
 * - 912345678
 * - +249912345678
 * - 00249912345678
 * - 249912345678
 * - +249 912-345-678
 */
export const validateSudanPhoneNumber = (input: string): PhoneValidationResult => {
  if (!input || input.trim() === '') {
    return {
      isValid: false,
      raw: '',
      international: '',
      local: '',
      whatsapp: '',
      errorAr: 'يرجى إدخال رقم الهاتف',
      errorEn: 'Please enter a phone number',
    };
  }

  // 1. Normalize Arabic numerals and remove all spaces, dashes, dots, parentheses
  let cleaned = normalizeArabicDigits(input.trim());
  cleaned = cleaned.replace(/[\s\-\(\)\.\/]/g, '');

  // 2. Identify and strip country code prefixes
  let remainder = cleaned;

  if (remainder.startsWith('+249')) {
    remainder = remainder.slice(4);
  } else if (remainder.startsWith('00249')) {
    remainder = remainder.slice(5);
  } else if (remainder.startsWith('249') && remainder.length >= 12) {
    remainder = remainder.slice(3);
  }

  // If user entered a leading 0 after prefix or in local format (e.g. 091... or +249091...)
  if (remainder.startsWith('0')) {
    remainder = remainder.slice(1);
  }

  // 3. Validation: Sudanese mobile numbers must have exactly 9 digits, starting with 9 or 1
  const isAllDigits = /^\d+$/.test(remainder);
  if (!isAllDigits) {
    return {
      isValid: false,
      raw: input,
      international: '',
      local: '',
      whatsapp: '',
      errorAr: 'يجب أن يحتوي رقم الهاتف على أرقام فقط',
      errorEn: 'Phone number must contain digits only',
    };
  }

  // Check if it matches Sudanese mobile pattern: exactly 9 digits starting with 9 or 1
  if (/^[19]\d{8}$/.test(remainder)) {
    const international = `+249${remainder}`;
    const local = `0${remainder}`;
    const whatsapp = `249${remainder}`;

    return {
      isValid: true,
      raw: input,
      international,
      local,
      whatsapp,
    };
  }

  // If user entered other digits, give descriptive error without truncating or assuming
  if (remainder.length < 9) {
    return {
      isValid: false,
      raw: input,
      international: '',
      local: '',
      whatsapp: '',
      errorAr: `رقم الهاتف غير مكتمل (${remainder.length} أرقام من أصل 9 أرقام مطلوبة لشبكات السودان)`,
      errorEn: `Phone number is too short (${remainder.length} digits, 9 required for Sudan)`,
    };
  }

  if (remainder.length > 9) {
    // If it's a general international number (non-Sudanese) starting with +
    if (cleaned.startsWith('+') && cleaned.length >= 10 && cleaned.length <= 16) {
      return {
        isValid: true,
        raw: input,
        international: cleaned,
        local: cleaned,
        whatsapp: cleaned.replace('+', ''),
      };
    }

    return {
      isValid: false,
      raw: input,
      international: '',
      local: '',
      whatsapp: '',
      errorAr: 'رقم الهاتف أطول من الصيغة السودانية المعتمدة (9 أرقام بعد مفتاح الدولة)',
      errorEn: 'Phone number exceeds valid Sudanese format (9 digits after country code)',
    };
  }

  // If 9 digits but doesn't start with 9 or 1
  return {
    isValid: false,
    raw: input,
    international: '',
    local: '',
    whatsapp: '',
    errorAr: 'يجب أن يبدأ رقم الهاتف السوداني بـ 09 (زين/MTN) أو 01 (سوداني)',
    errorEn: 'Sudanese mobile numbers must start with 09 (Zain/MTN) or 01 (Sudani)',
  };
};

/**
 * Formats a phone number for display (e.g. "+249 91 234 5678" or "091 234 5678")
 */
export const formatDisplayPhone = (phone: string, mode: 'international' | 'local' = 'international'): string => {
  const result = validateSudanPhoneNumber(phone);
  if (!result.isValid) return phone || '';

  if (mode === 'local') {
    // 091 234 5678
    const digits = result.local;
    if (digits.length === 10) {
      return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6)}`;
    }
    return result.local;
  }

  // +249 91 234 5678
  const remainder = result.international.replace('+249', '');
  if (remainder.length === 9) {
    return `+249 ${remainder.slice(0, 2)} ${remainder.slice(2, 5)} ${remainder.slice(5)}`;
  }
  return result.international;
};
