import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Screen, Listing, FilterState, UserProfile, AppNotification } from '../types';
import { MOCK_LISTINGS, MOCK_NOTIFICATIONS, INITIAL_USER } from '../data/mockData';
import { 
  getSupabaseClient, 
  isSupabaseConfigured, 
  fetchDbListings, 
  insertDbListing, 
  uploadListingImage, 
  setSupabaseAnonKey, 
  getSupabaseAnonKey,
  DbListingRow,
  CreateListingPayload,
  SUPABASE_URL,
  translateSupabaseAuthError
} from '../lib/supabase';
import { CATEGORIES } from '../data/mockData';
import { User as SupabaseAuthUser } from '@supabase/supabase-js';
import { Language, translations, getTranslation } from '../lib/i18n';
import { validateSudanPhoneNumber } from '../lib/phoneUtils';

interface AppContextType {
  currentScreen: Screen;
  screenHistory: Screen[];
  navigate: (screen: Screen, listing?: Listing) => void;
  goBack: () => void;
  selectedListing: Listing | null;
  setSelectedListing: (listing: Listing | null) => void;

  // Language & i18n
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations['ar'], params?: Record<string, string | number>) => string;
  isRtl: boolean;
  
  // Filters & Search
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  isCityModalOpen: boolean;
  setIsCityModalOpen: (open: boolean) => void;

  // Data & Listings
  allListings: Listing[];
  favorites: string[];
  toggleFavorite: (listingId: string) => void;
  isFavorite: (listingId: string) => boolean;
  userListings: Listing[];
  
  // Supabase Status & Operations
  supabaseConnected: boolean;
  isDbLoading: boolean;
  dbError: string | null;
  refreshListings: () => Promise<void>;
  createDbListing: (
    listingData: CreateListingPayload,
    imageFiles: File[]
  ) => Promise<{ success: boolean; listing?: Listing; error?: string }>;
  
  // Local fallback addListing
  addListing: (newListing: Omit<Listing, 'id' | 'createdAt' | 'viewsCount' | 'seller'>) => Listing;

  // Supabase Auth & Profile
  user: UserProfile | null;
  supabaseUser: SupabaseAuthUser | null;
  isLoggedIn: boolean;
  signUpWithSupabase: (email: string, password: string, name: string, phone: string, city?: string) => Promise<{ success: boolean; error?: string }>;
  signInWithSupabase: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOutWithSupabase: () => Promise<void>;
  updateUserProfile: (data: { name: string; email?: string; phone: string; city?: string }) => Promise<{ success: boolean; emailUpdated?: boolean; error?: string }>;
  
  // Legacy mock login helpers
  loginUser: (phone: string) => void;
  logoutUser: () => void;

  // Notifications
  notifications: AppNotification[];
  markNotificationAsRead: (id: string) => void;
  unreadCount: number;

  // UI state simulation
  simulatedState: 'normal' | 'loading' | 'empty' | 'error';
  setSimulatedState: (state: 'normal' | 'loading' | 'empty' | 'error') => void;

  // Device simulation frame
  deviceMode: 'mobile' | 'tablet' | 'full';
  setDeviceMode: (mode: 'mobile' | 'tablet' | 'full') => void;

  // Supabase Key Management Modal
  isSupabaseModalOpen: boolean;
  setIsSupabaseModalOpen: (open: boolean) => void;
  saveSupabaseAnonKey: (key: string) => void;
  supabaseAnonKey: string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const initialFilters: FilterState = {
  query: '',
  categoryId: 'all',
  city: 'all',
  minPrice: undefined,
  maxPrice: undefined,
  sortBy: 'latest',
};

// Map database row to UI Listing model
const mapDbListingToAppListing = (row: DbListingRow): Listing => {
  const images = (row.image_urls && row.image_urls.length > 0)
    ? row.image_urls
    : (row.images && row.images.length > 0)
    ? row.images
    : ['https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80'];

  let createdAtFormatted = 'حديثاً';
  try {
    if (row.created_at) {
      const d = new Date(row.created_at);
      createdAtFormatted = d.toLocaleDateString('ar-SD', { month: 'short', day: 'numeric' });
    }
  } catch (e) {
    createdAtFormatted = 'الآن';
  }

  // Parse description for embedded metadata or extra attributes
  let cleanDescription = row.description || '';
  let parsedSubCategory = row.sub_category;
  let parsedDistrict = row.district;
  let parsedIsNegotiable = row.is_negotiable;
  let parsedPhone = row.seller_phone;
  let parsedWhatsapp = row.seller_whatsapp;
  let parsedAttributes: Record<string, any> = row.attributes || {};

  const metaMatch = cleanDescription.match(/<!--metadata:(.*?)-->/);
  if (metaMatch) {
    try {
      const meta = JSON.parse(metaMatch[1]);
      if (meta.subCategory && !parsedSubCategory) parsedSubCategory = meta.subCategory;
      if (meta.district && !parsedDistrict) parsedDistrict = meta.district;
      if (meta.isNegotiable !== undefined && parsedIsNegotiable === undefined) parsedIsNegotiable = meta.isNegotiable;
      if (meta.phone && !parsedPhone) parsedPhone = meta.phone;
      if (meta.whatsapp && !parsedWhatsapp) parsedWhatsapp = meta.whatsapp;
      if (meta.attributes) {
        parsedAttributes = { ...parsedAttributes, ...meta.attributes };
      }
      cleanDescription = cleanDescription.replace(/<!--metadata:.*?-->/, '').trim();
    } catch (e) {
      // Ignored
    }
  }

  // Fallback regex matching for human-readable items if created without metadata tag
  if (!parsedDistrict) {
    const dMatch = cleanDescription.match(/[•\-\*]\s*(?:الحي|المنطقة|الحي \/ المنطقة):\s*([^\n\r]+)/);
    if (dMatch) parsedDistrict = dMatch[1].trim();
  }
  if (!parsedSubCategory) {
    const sMatch = cleanDescription.match(/[•\-\*]\s*(?:القسم الفرعي|التصنيف الفرعي):\s*([^\n\r]+)/);
    if (sMatch) parsedSubCategory = sMatch[1].trim();
  }
  if (!parsedPhone) {
    const pMatch = cleanDescription.match(/[•\-\*]\s*(?:هاتف التواصل|رقم التواصل|هاتف|جوال):\s*([^\n\r]+)/);
    if (pMatch) parsedPhone = pMatch[1].trim();
  }

  // Resolve category: column is 'category' in Supabase listings table
  const rawCat = (row.category || row.category_id || 'cars').toString();
  const matchedCat = CATEGORIES.find(
    (c) => c.id === rawCat || c.nameAr === rawCat || c.nameEn.toLowerCase() === rawCat.toLowerCase()
  );
  const resolvedCategoryId = matchedCat ? matchedCat.id : rawCat;

  // Standardize seller phone & WhatsApp if present, or leave empty (never mock fake numbers)
  let cleanSellerPhone = '';
  let cleanSellerWhatsapp = '';
  const rawCandidatePhone = parsedPhone || row.seller_phone || '';
  if (rawCandidatePhone && rawCandidatePhone.trim() !== '') {
    const pRes = validateSudanPhoneNumber(rawCandidatePhone);
    if (pRes.isValid) {
      cleanSellerPhone = pRes.international;
      cleanSellerWhatsapp = pRes.whatsapp;
    } else {
      cleanSellerPhone = rawCandidatePhone.trim();
      cleanSellerWhatsapp = rawCandidatePhone.replace(/[^0-9]/g, '');
    }
  }

  if (parsedWhatsapp || row.seller_whatsapp) {
    const rawWa = (parsedWhatsapp || row.seller_whatsapp || '').trim();
    if (rawWa) {
      const wRes = validateSudanPhoneNumber(rawWa);
      if (wRes.isValid) {
        cleanSellerWhatsapp = wRes.whatsapp;
      }
    }
  }

  return {
    id: row.id.toString(),
    title: row.title,
    description: cleanDescription,
    price: Number(row.price) || 0,
    isNegotiable: parsedIsNegotiable ?? (row.is_negotiable ?? true),
    categoryId: resolvedCategoryId,
    subCategory: parsedSubCategory,
    city: row.city || 'الخرطوم',
    district: parsedDistrict,
    images: images,
    createdAt: createdAtFormatted,
    featured: Boolean(row.featured),
    viewsCount: Number(row.views_count) || 1,
    seller: {
      id: row.seller_id,
      name: row.seller_name || 'عضو سوق السودان',
      phone: cleanSellerPhone,
      whatsapp: cleanSellerWhatsapp || cleanSellerPhone,
      verified: Boolean(row.seller_verified),
      rating: 5.0,
      memberSince: '2026',
      totalListings: 1,
    },
    attributes: parsedAttributes,
  };
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [screenHistory, setScreenHistory] = useState<Screen[]>(['home']);
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  
  const [filters, setFilters] = useState<FilterState>(initialFilters);
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [isCityModalOpen, setIsCityModalOpen] = useState(false);

  const [allListings, setAllListings] = useState<Listing[]>(MOCK_LISTINGS);
  const [favorites, setFavorites] = useState<string[]>(['sd-101', 'sd-103']);
  const [userListings, setUserListings] = useState<Listing[]>([]);

  // Supabase states
  const [supabaseConnected, setSupabaseConnected] = useState<boolean>(isSupabaseConfigured());
  const [supabaseUser, setSupabaseUser] = useState<SupabaseAuthUser | null>(null);
  const [isDbLoading, setIsDbLoading] = useState<boolean>(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);
  const [supabaseAnonKey, setSupabaseAnonKeyState] = useState<string>(getSupabaseAnonKey());

  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Language & i18n
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('sudan_souq_language');
      if (saved === 'en' || saved === 'ar') return saved;
    } catch (e) {}
    return 'ar';
  });

  const isRtl = language === 'ar';

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('sudan_souq_language', lang);
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    } catch (e) {}
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
  }, [language, isRtl]);

  const t = useCallback(
    (key: keyof typeof translations['ar'], params?: Record<string, string | number>) => {
      return getTranslation(language, key, params);
    },
    [language]
  );

  const [notifications, setNotifications] = useState<AppNotification[]>(MOCK_NOTIFICATIONS);
  const [simulatedState, setSimulatedState] = useState<'normal' | 'loading' | 'empty' | 'error'>('normal');
  const [deviceMode, setDeviceMode] = useState<'mobile' | 'tablet' | 'full'>('mobile');

  // Fetch real listings from Supabase
  const refreshListings = useCallback(async () => {
    if (!isSupabaseConfigured()) {
      setSupabaseConnected(false);
      return;
    }

    setIsDbLoading(true);
    setDbError(null);

    const { data, error } = await fetchDbListings();

    setIsDbLoading(false);

    if (error) {
      console.warn('Error fetching listings from Supabase:', error);
      setDbError(error.message || 'حدث خطأ في جلب الإعلانات من قاعدة البيانات');
      // Keep existing data to prevent UI breakdown
    } else if (data) {
      setSupabaseConnected(true);
      const mapped = data.map(mapDbListingToAppListing);
      // If table has live records, use them
      if (mapped.length > 0) {
        setAllListings(mapped);
      } else {
        // Table is empty in Supabase
        setAllListings([]);
      }
    }
  }, []);

  // Listen to Supabase Auth state changes
  useEffect(() => {
    const client = getSupabaseClient();
    if (!client) {
      setSupabaseConnected(false);
      return;
    }

    setSupabaseConnected(true);

    // Initial session check
    client.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const meta = session.user.user_metadata || {};
        const realAvatar = meta.avatar_url || meta.avatarUrl || undefined;
        setSupabaseUser(session.user);
        setIsLoggedIn(true);
        setUser({
          id: session.user.id,
          name: meta.name || session.user.email?.split('@')[0] || 'عضو سوق السودان',
          email: session.user.email || undefined,
          phone: meta.phone || session.user.phone || '',
          city: meta.city || 'بورتسودان',
          avatarUrl: realAvatar,
          verified: Boolean(meta.verified),
          joinDate: new Date(session.user.created_at).toLocaleDateString('ar-SD', { month: 'short', year: 'numeric' }),
        });
      } else {
        setSupabaseUser(null);
        setIsLoggedIn(false);
        setUser(null);
      }
    });

    const { data: authListener } = client.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        const meta = session.user.user_metadata || {};
        const realAvatar = meta.avatar_url || meta.avatarUrl || undefined;
        setSupabaseUser(session.user);
        setIsLoggedIn(true);
        setUser({
          id: session.user.id,
          name: meta.name || session.user.email?.split('@')[0] || 'عضو سوق السودان',
          email: session.user.email || undefined,
          phone: meta.phone || session.user.phone || '',
          city: meta.city || 'بورتسودان',
          avatarUrl: realAvatar,
          verified: Boolean(meta.verified),
          joinDate: new Date(session.user.created_at).toLocaleDateString('ar-SD', { month: 'short', year: 'numeric' }),
        });
      } else {
        setSupabaseUser(null);
        setIsLoggedIn(false);
        setUser(null);
      }
    });

    // Fetch initial listings
    refreshListings();

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [refreshListings]);

  // Update user listings based on seller_id
  useEffect(() => {
    if (supabaseUser) {
      const userItems = allListings.filter((l) => l.seller.id === supabaseUser.id);
      setUserListings(userItems);
    } else if (user) {
      const userItems = allListings.filter((l) => l.seller.id === user.id);
      setUserListings(userItems);
    } else {
      setUserListings([]);
    }
  }, [allListings, supabaseUser, user]);

  const saveSupabaseAnonKey = (key: string) => {
    setSupabaseAnonKey(key);
    setSupabaseAnonKeyState(key);
    setSupabaseConnected(isSupabaseConfigured());
    // Trigger fresh load
    setTimeout(() => {
      refreshListings();
    }, 200);
  };

  const navigate = (screen: Screen, listing?: Listing) => {
    if (listing) {
      setSelectedListing(listing);
    }
    setScreenHistory((prev) => [...prev, screen]);
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = [...screenHistory];
      newHistory.pop();
      const previous = newHistory[newHistory.length - 1];
      setScreenHistory(newHistory);
      setCurrentScreen(previous);
    } else {
      setCurrentScreen('home');
    }
  };

  const resetFilters = () => {
    setFilters({
      query: '',
      categoryId: 'all',
      city: selectedCity,
      minPrice: undefined,
      maxPrice: undefined,
      sortBy: 'latest',
    });
  };

  const toggleFavorite = (listingId: string) => {
    setFavorites((prev) =>
      prev.includes(listingId) ? prev.filter((id) => id !== listingId) : [...prev, listingId]
    );
  };

  const isFavorite = (listingId: string) => favorites.includes(listingId);

  // Supabase Listing Creation with Image Upload
  const createDbListing = async (
    listingData: CreateListingPayload,
    imageFiles: File[]
  ): Promise<{ success: boolean; listing?: Listing; error?: string }> => {
    if (!supabaseUser) {
      return { success: false, error: 'يجب تسجيل الدخول بحساب موثق أولاً لنشر إعلان في قاعدة البيانات' };
    }

    const client = getSupabaseClient();
    if (!client) {
      return { success: false, error: 'الاتصال بـ Supabase غير مهيأ. يرجى إدخال المفتاح العام (Anon Key).' };
    }

    try {
      const uploadedUrls: string[] = [];

      // 1. Upload files to Supabase Storage 'listing-images' bucket
      for (const file of imageFiles) {
        const { publicUrl, error: uploadErr } = await uploadListingImage(file, supabaseUser.id);
        if (uploadErr) {
          console.warn('Storage upload error:', uploadErr);
          return {
            success: false,
            error: `تعذر رفع الصورة إلى مخزن listing-images: ${uploadErr.message || 'تحقق من صلاحيات Storage Bucket'}`,
          };
        }
        if (publicUrl) {
          uploadedUrls.push(publicUrl);
        }
      }

      // Combine uploaded images with any preset sample URLs selected
      const combinedImageUrls = [
        ...uploadedUrls,
        ...(listingData.preset_image_urls || []),
      ];

      // 2. Insert into public.listings (ONLY valid columns sent: id, seller_id, title, description, price, category, city, image_urls, status)
      const { data, error } = await insertDbListing(
        {
          ...listingData,
          image_urls: combinedImageUrls,
        },
        supabaseUser
      );

      if (error) {
        return {
          success: false,
          error: `تعذر حفظ الإعلان في جدول listings: ${error.message || 'حدث خطأ أثناء الحفظ'}`,
        };
      }

      if (data) {
        const appListing = mapDbListingToAppListing(data);
        setAllListings((prev) => [appListing, ...prev]);
        setUserListings((prev) => [appListing, ...prev]);
        return { success: true, listing: appListing };
      }

      return { success: false, error: 'لم يتم استرجاع بيانات الإعلان من الخادم' };
    } catch (err: any) {
      return { success: false, error: err.message || 'حدث خطأ غير متوقع أثناء الحفظ' };
    }
  };

  // Local fallback creation
  const addListing = (data: Omit<Listing, 'id' | 'createdAt' | 'viewsCount' | 'seller'>): Listing => {
    const newId = `sd-user-${Date.now().toString().slice(-4)}`;
    const created: Listing = {
      ...data,
      id: newId,
      createdAt: 'الآن',
      viewsCount: 1,
      seller: {
        id: user?.id || 'guest',
        name: user?.name || 'مستخدم جديد',
        phone: user?.phone || '',
        whatsapp: user?.phone || '',
        verified: false,
        rating: 5.0,
        memberSince: '2026',
        totalListings: (userListings.length || 0) + 1,
      },
    };

    setAllListings((prev) => [created, ...prev]);
    setUserListings((prev) => [created, ...prev]);
    return created;
  };

  // Supabase Auth SignUp
  const signUpWithSupabase = async (
    email: string,
    password: string,
    name: string,
    phone: string,
    city?: string
  ): Promise<{ success: boolean; error?: string }> => {
    const client = getSupabaseClient();
    if (!client) {
      return { success: false, error: 'الاتصال بـ Supabase غير مهيأ. يرجى إدخال المفتاح العام (Anon Key).' };
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'يرجى إدخال بريد إلكتروني صحيح مثل name@example.com' };
    }

    if (!password || password.length < 6) {
      return { success: false, error: 'كلمة المرور يجب ألا تقل عن 6 خانات' };
    }

    try {
      const { data, error } = await client.auth.signUp({
        email: cleanEmail,
        password,
        options: {
          data: {
            name: name.trim(),
            phone: phone.trim(),
            whatsapp: phone.trim(),
            verified: false,
            city: city || (selectedCity !== 'all' ? selectedCity : 'بورتسودان'),
          },
        },
      });

      if (error) {
        return { success: false, error: translateSupabaseAuthError(error) };
      }

      if (data.session?.user || data.user) {
        const authedUser = data.session?.user || data.user;
        const meta = authedUser!.user_metadata || {};
        const realAvatar = meta.avatar_url || meta.avatarUrl || undefined;
        setSupabaseUser(authedUser!);
        setIsLoggedIn(true);
        setUser({
          id: authedUser!.id,
          name: meta.name || name.trim() || authedUser!.email?.split('@')[0] || 'عضو سوق السودان',
          phone: meta.phone || phone.trim() || '',
          city: meta.city || city || 'بورتسودان',
          avatarUrl: realAvatar,
          verified: false,
          joinDate: 'اليوم',
        });
        return { success: true };
      }

      return { success: false, error: 'لم تكتمل عملية التسجيل' };
    } catch (err: any) {
      return { success: false, error: translateSupabaseAuthError(err) };
    }
  };

  // Supabase Auth SignIn
  const signInWithSupabase = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    const client = getSupabaseClient();
    if (!client) {
      return { success: false, error: 'الاتصال بـ Supabase غير مهيأ. يرجى إدخال المفتاح العام (Anon Key).' };
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'يرجى إدخال البريد الإلكتروني المسجل به الحساب' };
    }

    try {
      const { data, error } = await client.auth.signInWithPassword({
        email: cleanEmail,
        password,
      });

      if (error) {
        return { success: false, error: translateSupabaseAuthError(error) };
      }

      if (data.user) {
        const meta = data.user.user_metadata || {};
        const realAvatar = meta.avatar_url || meta.avatarUrl || undefined;
        setSupabaseUser(data.user);
        setIsLoggedIn(true);
        setUser({
          id: data.user.id,
          name: meta.name || data.user.email?.split('@')[0] || 'عضو سوق السودان',
          phone: meta.phone || data.user.phone || '',
          city: meta.city || 'بورتسودان',
          avatarUrl: realAvatar,
          verified: Boolean(meta.verified),
          joinDate: new Date(data.user.created_at).toLocaleDateString('ar-SD', { month: 'short', year: 'numeric' }),
        });
        return { success: true };
      }

      return { success: false, error: 'بيانات الدخول غير صحيحة' };
    } catch (err: any) {
      return { success: false, error: translateSupabaseAuthError(err) };
    }
  };

  // Supabase Auth SignOut
  const signOutWithSupabase = async () => {
    const client = getSupabaseClient();
    if (client) {
      await client.auth.signOut();
    }
    setSupabaseUser(null);
    setIsLoggedIn(false);
    setUser(null);
  };

  // Update User Profile (Metadata & Auth Email)
  const updateUserProfile = async (
    data: { name: string; email?: string; phone: string; city?: string }
  ): Promise<{ success: boolean; emailUpdated?: boolean; error?: string }> => {
    if (!isLoggedIn) {
      return { success: false, error: language === 'ar' ? 'يجب تسجيل الدخول لتعديل الحساب' : 'Please sign in to update account' };
    }

    // Standardize phone if provided
    let stdPhone = '';
    if (data.phone && data.phone.trim() !== '') {
      const pRes = validateSudanPhoneNumber(data.phone);
      if (!pRes.isValid) {
        return {
          success: false,
          error: language === 'ar' ? (pRes.errorAr || 'رقم الهاتف غير صالح') : (pRes.errorEn || 'Invalid phone number'),
        };
      }
      stdPhone = pRes.international;
    }

    const client = getSupabaseClient();
    if (client && supabaseUser) {
      const emailChanged = Boolean(
        data.email && data.email.trim().toLowerCase() !== supabaseUser.email?.toLowerCase()
      );

      const updatePayload: any = {
        data: {
          name: data.name.trim(),
          phone: stdPhone,
          city: data.city || user?.city || 'بورتسودان',
        },
      };

      if (emailChanged && data.email) {
        updatePayload.email = data.email.trim();
      }

      const { data: updated, error } = await client.auth.updateUser(updatePayload);

      if (error) {
        return { success: false, error: translateSupabaseAuthError(error) };
      }

      if (updated.user) {
        setSupabaseUser(updated.user);
        const meta = updated.user.user_metadata || {};
        setUser((prev) => prev ? ({
          ...prev,
          name: meta.name || data.name.trim(),
          email: updated.user.email || prev.email,
          phone: meta.phone || stdPhone,
          city: meta.city || prev.city,
        }) : null);
      }

      return { success: true, emailUpdated: emailChanged };
    } else {
      // Local fallback mode
      setUser((prev) => prev ? ({
        ...prev,
        name: data.name.trim(),
        email: data.email || prev.email,
        phone: stdPhone,
        city: data.city || prev.city,
      }) : null);
      return { success: true };
    }
  };

  // Legacy mock fallback
  const loginUser = (phone: string) => {
    setUser({
      id: 'usr-new-' + Date.now().toString().slice(-4),
      name: 'عضو سوق السودان',
      phone: phone,
      city: selectedCity !== 'all' ? selectedCity : 'الخرطوم',
      avatarUrl: undefined,
      verified: true,
      joinDate: 'اليوم',
    });
    setIsLoggedIn(true);
  };

  const logoutUser = () => {
    signOutWithSupabase();
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AppContext.Provider
      value={{
        currentScreen,
        screenHistory,
        navigate,
        goBack,
        selectedListing,
        setSelectedListing,
        language,
        setLanguage,
        t,
        isRtl,
        filters,
        setFilters,
        resetFilters,
        selectedCity,
        setSelectedCity,
        isCityModalOpen,
        setIsCityModalOpen,
        allListings,
        favorites,
        toggleFavorite,
        isFavorite,
        userListings,
        supabaseConnected,
        isDbLoading,
        dbError,
        refreshListings,
        createDbListing,
        addListing,
        user,
        supabaseUser,
        isLoggedIn,
        signUpWithSupabase,
        signInWithSupabase,
        signOutWithSupabase,
        updateUserProfile,
        loginUser,
        logoutUser,
        notifications,
        markNotificationAsRead,
        unreadCount,
        simulatedState,
        setSimulatedState,
        deviceMode,
        setDeviceMode,
        isSupabaseModalOpen,
        setIsSupabaseModalOpen,
        saveSupabaseAnonKey,
        supabaseAnonKey,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
