import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { UserAvatar } from '../components/UserAvatar';
import { CITIES } from '../data/mockData';
import { validateSudanPhoneNumber, formatDisplayPhone } from '../lib/phoneUtils';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Save, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  ArrowRight,
  ArrowLeft,
  Calendar,
  Key,
  ShieldCheck,
  Info
} from 'lucide-react';

export const AccountSettingsScreen: React.FC = () => {
  const { 
    user, 
    supabaseUser,
    isLoggedIn, 
    updateUserProfile, 
    goBack, 
    navigate,
    t,
    isRtl,
    language
  } = useApp();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || supabaseUser?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [city, setCity] = useState(user?.city || 'بورتسودان');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [emailNotice, setEmailNotice] = useState<string | null>(null);

  // Sync initial values
  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setPhone(user.phone || '');
      setCity(user.city || 'بورتسودان');
    }
    if (supabaseUser?.email) {
      setEmail(supabaseUser.email);
    }
  }, [user, supabaseUser]);

  // Live phone validation
  const phoneValidation = validateSudanPhoneNumber(phone);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);
    setEmailNotice(null);

    if (!name.trim()) {
      setErrorMessage(t('fieldRequired') + ': ' + t('displayNameLabel'));
      return;
    }

    if (phone.trim() && !phoneValidation.isValid) {
      setErrorMessage(language === 'ar' ? (phoneValidation.errorAr || t('invalidPhoneError')) : (phoneValidation.errorEn || t('invalidPhoneError')));
      return;
    }

    setIsSubmitting(true);

    try {
      const result = await updateUserProfile({
        name: name.trim(),
        email: email.trim() || undefined,
        phone: phone.trim() ? phoneValidation.international : '',
        city,
      });

      setIsSubmitting(false);

      if (result.success) {
        setSuccessMessage(t('accountUpdateSuccess'));
        if (result.emailUpdated) {
          setEmailNotice(t('accountUpdateEmailNotice'));
        }
      } else {
        setErrorMessage(result.error || t('errorTitle'));
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage(err.message || t('errorTitle'));
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="pb-16 px-4 pt-10 min-h-screen flex items-center justify-center bg-slate-50" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="max-w-md w-full bg-white rounded-3xl p-6 border border-slate-200 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
            <User className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-slate-900">{t('loginRequiredToPost')}</h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            {t('loginRequiredSubtext')}
          </p>
          <div className="space-y-2 pt-2">
            <button
              onClick={() => navigate('auth_login')}
              className="w-full py-3.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-2xl font-bold text-sm shadow-md transition-all cursor-pointer"
            >
              {t('login')}
            </button>
            <button
              onClick={() => navigate('auth_register')}
              className="w-full py-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-2xl font-bold text-sm border border-emerald-200 transition-all cursor-pointer"
            >
              {t('register')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  return (
    <div className="pb-24 px-4 pt-3 bg-slate-50 min-h-screen space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Top Header Bar */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-emerald-800 transition-colors cursor-pointer py-1.5 px-2.5 rounded-xl hover:bg-slate-100"
        >
          <BackIcon className="w-4 h-4" />
          <span>{t('back')}</span>
        </button>
        <h1 className="text-base font-black text-slate-900">{t('accountSettingsTitle')}</h1>
        <div className="w-8" />
      </div>

      {/* Account Info Card */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center gap-3.5">
          <UserAvatar
            name={user?.name || ''}
            avatarUrl={user?.avatarUrl}
            size="lg"
            fallbackType="letter_s"
            className="w-14 h-14 rounded-2xl"
          />
          <div className="flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="font-black text-slate-900 text-base">{user?.name}</h3>
              {user?.verified && (
                <span className="text-[10px] bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>{t('verifiedSeller')}</span>
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-mono mt-0.5" dir="ltr">
              {email || supabaseUser?.email || ''}
            </p>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>{user?.joinDate ? `${t('memberSince')} ${user.joinDate}` : ''}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Security badge */}
        <div className="bg-slate-50 rounded-2xl p-2.5 border border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
          <div className="flex items-center gap-2">
            <Key className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="font-medium font-mono text-[10px] text-slate-500 truncate max-w-[200px]" dir="ltr">
              ID: {user?.id}
            </span>
          </div>
          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/60 px-2 py-0.5 rounded-full">
            {user?.verified ? t('verifiedStatusText') : t('unverifiedStatusText')}
          </span>
        </div>
      </div>

      {/* Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-3.5">
        {/* Success Alert */}
        {successMessage && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-2.5 shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="block font-bold">{successMessage}</strong>
              {emailNotice && (
                <p className="text-[11px] text-emerald-800 leading-relaxed font-medium">
                  {emailNotice}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 shadow-xs">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <strong className="block font-bold mb-0.5">{t('errorTitle')}</strong>
              <p className="text-[11px] leading-relaxed">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Display Name Field */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <User className="w-4 h-4 text-emerald-700" />
            <span>{t('displayNameLabel')}</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t('displayNamePlaceholder')}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
            required
          />
        </div>

        {/* Email Field */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Mail className="w-4 h-4 text-emerald-700" />
            <span>{t('emailLabel')}</span>
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={t('emailPlaceholder')}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 font-mono"
            dir="ltr"
            required
          />
          <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200/70 text-[11px] text-amber-900 flex items-start gap-2">
            <Info className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
            <span>{t('emailChangeNotice')}</span>
          </div>
        </div>

        {/* Phone Field */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-emerald-700" />
              <span>{t('phoneLabel')}</span>
            </span>
            {phone.trim() !== '' && (
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                phoneValidation.isValid ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {phoneValidation.isValid ? '✓ رقم سوداني معتمد' : 'غير مكتمل'}
              </span>
            )}
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder={t('phonePlaceholder')}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
            dir="ltr"
          />
          {phone.trim() !== '' && (
            <div className="text-[11px] space-y-1 pt-1">
              {phoneValidation.isValid ? (
                <div className="text-emerald-700 flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>الصيغة الدولية المعتمدة: </span>
                  <strong className="font-mono" dir="ltr">{phoneValidation.international}</strong>
                </div>
              ) : (
                <div className="text-rose-600 flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{language === 'ar' ? phoneValidation.errorAr : phoneValidation.errorEn}</span>
                </div>
              )}
            </div>
          )}
          <p className="text-[10px] text-slate-400">
            {t('phoneHintSudan')}
          </p>
        </div>

        {/* City Field */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-emerald-700" />
            <span>{t('cityLabel')}</span>
          </label>
          <select
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-emerald-700/30"
          >
            {CITIES.filter((c) => c.id !== 'all').map((c) => (
              <option key={c.id} value={c.nameAr}>
                {c.nameAr} ({c.region})
              </option>
            ))}
          </select>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white py-4 rounded-2xl font-bold text-sm shadow-md shadow-emerald-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{t('savingChanges')}</span>
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                <span>{t('saveChangesBtn')}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
