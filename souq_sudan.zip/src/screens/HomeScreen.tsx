import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CITIES } from '../data/mockData';
import { ListingCard } from '../components/ListingCard';
import { LoadingSkeleton, EmptyState, ErrorState } from '../components/StateFeedback';
import { 
  Search, 
  MapPin, 
  SlidersHorizontal, 
  ShieldCheck, 
  Sparkles, 
  Car, 
  Building, 
  Smartphone, 
  Armchair, 
  Refrigerator, 
  Shirt, 
  Briefcase, 
  Wrench,
  Grid3X3,
  ListFilter,
  ArrowLeft,
  User,
  LogIn,
  ChevronDown
} from 'lucide-react';

// Icon map for categories
const categoryIcons: Record<string, React.ElementType> = {
  cars: Car,
  real_estate: Building,
  phones_electronics: Smartphone,
  furniture: Armchair,
  appliances: Refrigerator,
  clothing: Shirt,
  jobs: Briefcase,
  services: Wrench,
};

export const HomeScreen: React.FC = () => {
  const { 
    navigate, 
    allListings, 
    selectedCity, 
    setIsCityModalOpen, 
    setFilters,
    simulatedState,
    setSimulatedState,
    isDbLoading,
    dbError,
    refreshListings,
    supabaseConnected,
    setIsSupabaseModalOpen,
    isLoggedIn,
    user
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'featured' | 'recent'>('all');
  const [viewLayout, setViewLayout] = useState<'horizontal' | 'grid'>('horizontal');

  // Filter listings based on current city
  const cityFilteredListings = selectedCity === 'all' 
    ? allListings 
    : allListings.filter((item) => {
        const cityObj = CITIES.find((c) => c.id === selectedCity);
        return cityObj ? item.city.includes(cityObj.nameAr) : true;
      });

  const featuredListings = cityFilteredListings.filter((l) => l.featured);
  
  const displayListings = activeTab === 'featured'
    ? featuredListings
    : activeTab === 'recent'
    ? [...cityFilteredListings].reverse()
    : cityFilteredListings;

  const currentCityObj = CITIES.find((c) => c.id === selectedCity) || CITIES[0];

  const handleCategoryClick = (categoryId: string) => {
    setFilters((prev) => ({ ...prev, categoryId }));
    navigate('search');
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Search Header Banner */}
      <div className="bg-gradient-to-b from-emerald-800 via-emerald-850 to-emerald-900 text-white px-4 pt-3.5 pb-5 rounded-b-3xl shadow-sm">
        {/* Top Row: City Selector and Slogan */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <button
            onClick={() => setIsCityModalOpen(true)}
            className="flex items-center gap-1.5 bg-white/15 hover:bg-white/20 active:bg-white/25 px-3 py-1.5 rounded-full text-xs font-bold text-white backdrop-blur-xs transition-colors border border-white/20 shadow-2xs"
            title="تغيير المدينة"
          >
            <MapPin className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <span className="truncate max-w-[120px]">{currentCityObj.nameAr}</span>
            <ChevronDown className="w-3 h-3 text-emerald-200 shrink-0" />
          </button>

          <span className="text-[11px] text-emerald-100 font-medium truncate">
            {isLoggedIn ? `مرحباً، ${user?.name?.split(' ')[0]}` : 'سوق الإعلانات الأول بالسودان'}
          </span>
        </div>

        {/* Quick Search Trigger Bar */}
        <div
          onClick={() => navigate('search')}
          className="bg-white rounded-2xl p-2.5 pr-3.5 flex items-center justify-between shadow-md text-slate-400 cursor-pointer hover:bg-slate-50 transition-all group"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <Search className="w-5 h-5 text-emerald-800 group-hover:scale-105 transition-transform shrink-0" />
            <span className="text-xs sm:text-sm text-slate-500 font-medium truncate">
              ابحث عن سيارات، عقارات، هواتف، أجهزة...
            </span>
          </div>
          <div className="w-8.5 h-8.5 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
            <SlidersHorizontal className="w-4 h-4" />
          </div>
        </div>

        {/* Safe Trading Notice */}
        <div className="mt-2.5 bg-emerald-950/40 border border-emerald-700/50 rounded-xl px-3 py-1.5 flex items-center gap-2 text-[11px] text-emerald-100">
          <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
          <span className="truncate">
            معاملات آمنة: عاين السلعة وافحصها قبل إتمام التحويل عبر بنكك أو فوري.
          </span>
        </div>
      </div>

      {/* Main Categories Section */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-1.5">
            <span>الأقسام الرئيسية</span>
          </h3>
          <button
            onClick={() => navigate('categories')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-900 flex items-center gap-1"
          >
            <span>عرض الكل</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Categories Grid/Row */}
        <div className="grid grid-cols-4 gap-2.5">
          {CATEGORIES.slice(0, 8).map((cat) => {
            const Icon = categoryIcons[cat.id] || Sparkles;
            return (
              <button
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                className="flex flex-col items-center p-2 rounded-2xl bg-white border border-slate-200/70 hover:border-emerald-700/40 hover:shadow-xs active:scale-95 transition-all text-center group"
              >
                <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 group-hover:bg-emerald-800 group-hover:text-white flex items-center justify-center transition-colors mb-1.5 shadow-2xs">
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-bold text-slate-800 group-hover:text-emerald-900 line-clamp-1">
                  {cat.nameAr}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {cat.listingsCount}+ إعلان
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured VIP Listings Section */}
      {featuredListings.length > 0 && (
        <div className="px-4 pt-2">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-5 bg-amber-500 rounded-full" />
              <h3 className="font-extrabold text-slate-900 text-base">إعلانات مميزة</h3>
            </div>
            <span className="text-xs text-amber-700 bg-amber-50 border border-amber-200/60 font-semibold px-2 py-0.5 rounded-full">
              عروض مختارة
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {featuredListings.slice(0, 2).map((item) => (
              <ListingCard key={item.id} listing={item} layout="grid" />
            ))}
          </div>
        </div>
      )}

      {/* Listings Section with Filters & View Switcher */}
      <div className="px-4 pt-2">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-base">أحدث الإعلانات</h3>
            <span className="text-xs text-slate-500 font-normal">
              ({displayListings.length})
            </span>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewLayout('horizontal')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewLayout === 'horizontal' ? 'bg-white shadow-xs text-emerald-800' : 'text-slate-500'
              }`}
              title="قائمة"
            >
              <ListFilter className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewLayout('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewLayout === 'grid' ? 'bg-white shadow-xs text-emerald-800' : 'text-slate-500'
              }`}
              title="شبكة"
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-colors ${
              activeTab === 'all'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setActiveTab('featured')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-colors ${
              activeTab === 'featured'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            المميزة فقط
          </button>
          <button
            onClick={() => setActiveTab('recent')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-colors ${
              activeTab === 'recent'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            الأحدث أولاً
          </button>
        </div>

        {/* Listings Display Based on State */}
        {isDbLoading || simulatedState === 'loading' ? (
          <LoadingSkeleton count={4} />
        ) : simulatedState === 'error' ? (
          <ErrorState onRetry={() => { setSimulatedState('normal'); refreshListings(); }} />
        ) : simulatedState === 'empty' || displayListings.length === 0 ? (
          <EmptyState
            title="لا توجد إعلانات في هذه المدينة حالياً"
            description="يمكنك تصفح إعلانات كل مدن السودان أو إضافة أول إعلان في هذه المدينة."
            actionText="عرض كل المدن"
            onAction={() => {
              setIsCityModalOpen(true);
            }}
          />
        ) : viewLayout === 'grid' ? (
          <div className="grid grid-cols-2 gap-3 mt-2">
            {displayListings.map((item) => (
              <ListingCard key={item.id} listing={item} layout="grid" />
            ))}
          </div>
        ) : (
          <div className="space-y-3 mt-2">
            {displayListings.map((item) => (
              <ListingCard key={item.id} listing={item} layout="horizontal" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
