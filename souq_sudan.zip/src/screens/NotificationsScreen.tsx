import React from 'react';
import { useApp } from '../context/AppContext';
import { Bell, ShieldCheck, Tag, Info, CheckCheck } from 'lucide-react';
import { EmptyState } from '../components/StateFeedback';

export const NotificationsScreen: React.FC = () => {
  const { notifications, markNotificationAsRead, navigate, allListings } = useApp();

  const handleNotificationClick = (notif: typeof notifications[0]) => {
    markNotificationAsRead(notif.id);
    if (notif.targetListingId) {
      const target = allListings.find((l) => l.id === notif.targetListingId);
      if (target) {
        navigate('listing_detail', target);
      }
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'price_drop':
        return <Tag className="w-4 h-4 text-emerald-700" />;
      case 'system':
        return <ShieldCheck className="w-4 h-4 text-amber-600" />;
      default:
        return <Info className="w-4 h-4 text-emerald-800" />;
    }
  };

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      {notifications.length === 0 ? (
        <EmptyState
          title="لا توجد إشعارات حالياً"
          description="ستصلك هنا تنبيهات عندما يطرأ تغيير على الأسعار في إعلاناتك المفضلة أو تصلك رسائل واستفسارات."
          actionText="العودة للرئيسية"
          onAction={() => navigate('home')}
        />
      ) : (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
            <span>التنبيهات وتحديثات السوق</span>
            <span className="flex items-center gap-1 text-emerald-800 font-bold">
              <CheckCheck className="w-3.5 h-3.5" />
              <span>محدث باستمرار</span>
            </span>
          </div>

          {notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex gap-3 ${
                n.isRead
                  ? 'bg-white border-slate-200/70 opacity-90'
                  : 'bg-emerald-50/50 border-emerald-300 shadow-2xs'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0">
                {getIcon(n.type)}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between gap-1 mb-1">
                  <h4 className="font-bold text-slate-900 text-xs">{n.title}</h4>
                  <span className="text-[10px] text-slate-400 font-normal">{n.timestamp}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                {n.targetListingId && (
                  <span className="inline-block mt-2 text-[11px] font-bold text-emerald-800 underline">
                    عرض الإعلان المرتبط ←
                  </span>
                )}
              </div>

              {!n.isRead && (
                <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0 self-start mt-2" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
