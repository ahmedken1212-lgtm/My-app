import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CITIES } from '../data/mockData';
import { 
  Camera, 
  Upload, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Plus, 
  Image as ImageIcon,
  MapPin,
  Tag,
  DollarSign,
  FileText,
  Phone,
  Loader2,
  Database,
  LogIn,
  UserPlus
} from 'lucide-react';

const SAMPLE_IMAGE_PRESETS = [
  { label: 'سيارة', url: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80' },
  { label: 'شقة/منزل', url: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80' },
  { label: 'هاتف ذكي', url: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80' },
  { label: 'طاقة شمسية', url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80' },
  { label: 'أثاث منزلي', url: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80' },
];

import { validateSudanPhoneNumber, formatDisplayPhone } from '../lib/phoneUtils';

export const CreateListingScreen: React.FC = () => {
  const { 
    createDbListing, 
    addListing, 
    navigate, 
    user, 
    supabaseUser,
    isLoggedIn, 
    supabaseConnected,
    setIsSupabaseModalOpen,
    t,
    isRtl,
    language
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [categoryId, setCategoryId] = useState(CATEGORIES[0].id);
  const [subCategory, setSubCategory] = useState(CATEGORIES[0].subcategories[0]);
  const [city, setCity] = useState(CITIES[1].nameAr);
  const [district, setDistrict] = useState('');
  
  // Real files to be uploaded to Supabase Storage 'listing-images'
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  // Preview URLs
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  // Fallback preset URLs
  const [presetUrls, setPresetUrls] = useState<string[]>([
    'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80'
  ]);

  // Account phone vs custom phone option
  const hasAccountPhone = Boolean(user?.phone && user.phone.trim() !== '');
  const [useAccountPhone, setUseAccountPhone] = useState<boolean>(hasAccountPhone);
  const [customPhone, setCustomPhone] = useState<string>(hasAccountPhone ? '' : (user?.phone || ''));

  const effectivePhone = (useAccountPhone && hasAccountPhone) ? (user?.phone || '') : customPhone;
  const phoneValidation = validateSudanPhoneNumber(effectivePhone);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionProgress, setSubmissionProgress] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState(false);
  const [bypassLoginGate, setBypassLoginGate] = useState(false);

  const currentCategory = CATEGORIES.find((c) => c.id === categoryId) || CATEGORIES[0];

  // Handle file selection from local device storage
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      const remainingSlots = 5 - (selectedFiles.length + previewUrls.length);
      const filesToAdd = filesArray.slice(0, remainingSlots);

      setSelectedFiles((prev) => [...prev, ...filesToAdd]);

      // Generate local object URLs for instant preview
      const newPreviews = filesToAdd.map((file) => URL.createObjectURL(file));
      setPreviewUrls((prev) => [...prev, ...newPreviews]);
      // Clear preset urls once real files added
      setPresetUrls([]);
    }
  };

  const handleAddSampleImage = (url: string) => {
    if (presetUrls.length + previewUrls.length < 5) {
      setPresetUrls((prev) => [...prev, url]);
    }
  };

  const handleRemoveImage = (index: number, isRealFile: boolean) => {
    if (isRealFile) {
      setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
      setPreviewUrls((prev) => {
        URL.revokeObjectURL(prev[index]);
        return prev.filter((_, i) => i !== index);
      });
    } else {
      setPresetUrls((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setErrorMessage(t('fieldRequired') + ': ' + t('adTitle'));
      return;
    }
    if (!price || parseFloat(price) <= 0) {
      setErrorMessage(t('fieldRequired') + ': ' + t('priceLabel'));
      return;
    }
    if (!description.trim()) {
      setErrorMessage(t('fieldRequired') + ': ' + t('descriptionLabel'));
      return;
    }

    if (!effectivePhone.trim()) {
      setErrorMessage(t('fieldRequired') + ': ' + t('contactSection'));
      return;
    }
    if (!phoneValidation.isValid) {
      setErrorMessage(language === 'ar' ? (phoneValidation.errorAr || t('invalidPhoneError')) : (phoneValidation.errorEn || t('invalidPhoneError')));
      return;
    }

    setErrorMessage('');

    // If Supabase is connected
    if (supabaseConnected) {
      if (!isLoggedIn || !supabaseUser) {
        setErrorMessage(t('loginRequiredSubtext'));
        return;
      }

      setIsSubmitting(true);
      setSubmissionProgress(t('publishingProgress'));

      const result = await createDbListing(
        {
          title: title.trim(),
          description: description.trim(),
          price: parseFloat(price),
          is_negotiable: isNegotiable,
          category: categoryId,
          category_id: categoryId,
          sub_category: subCategory,
          city,
          district: district.trim() || undefined,
          seller_phone: phoneValidation.international,
          seller_whatsapp: phoneValidation.international,
          preset_image_urls: presetUrls,
        },
        selectedFiles
      );

      setIsSubmitting(false);

      if (result.success && result.listing) {
        setSuccessMessage(true);
        setTimeout(() => {
          navigate('listing_detail', result.listing);
        }, 1200);
      } else {
        setErrorMessage(result.error || t('errorTitle'));
      }
    } else {
      // Fallback local mode if Supabase key not provided yet
      const combinedImages = [
        ...previewUrls,
        ...presetUrls,
      ];

      const created = addListing({
        title: title.trim(),
        description: description.trim(),
        price: parseFloat(price),
        isNegotiable,
        categoryId,
        subCategory,
        city,
        district: district.trim() || undefined,
        images: combinedImages.length > 0 ? combinedImages : [SAMPLE_IMAGE_PRESETS[0].url],
      });

      setSuccessMessage(true);
      setTimeout(() => {
        navigate('listing_detail', created);
      }, 1200);
    }
  };

  if (!isLoggedIn && !bypassLoginGate) {
    return (
      <div className="pb-16 px-4 pt-8 bg-slate-50 min-h-screen flex items-center justify-center" dir="rtl">
        <div className="max-w-md w-full bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-inner">
            <LogIn className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900">تسجيل الدخول مطلوب لنشر الإعلان</h2>
            <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
              لربط الإعلان برقم حسابك الموثق في قاعدة بيانات Supabase وضمان أمان المعاملات وتلقي رسائل المشترين، يرجى تسجيل الدخول أو إنشاء حساب جديد.
            </p>
          </div>

          <div className="space-y-2.5 pt-2">
            <button
              onClick={() => navigate('auth_login')}
              className="w-full py-3.5 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white rounded-2xl font-bold text-sm shadow-md shadow-emerald-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>تسجيل الدخول إلى حسابك</span>
            </button>

            <button
              onClick={() => navigate('auth_register')}
              className="w-full py-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-2xl font-bold text-sm border border-emerald-200/80 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserPlus className="w-4 h-4 text-emerald-700" />
              <span>إنشاء حساب جديد مجاناً</span>
            </button>
          </div>

          <div className="pt-2">
            <button
              onClick={() => setBypassLoginGate(true)}
              className="text-[11px] text-slate-400 hover:text-slate-600 underline"
            >
              متابعة كمسودة تجريبية فقط
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      {/* Database connection badge */}
      <div className={`rounded-2xl p-3.5 mb-4 text-xs border flex items-center justify-between ${
        supabaseConnected && isLoggedIn
          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
          : !isLoggedIn
          ? 'bg-amber-50 border-amber-200 text-amber-900'
          : 'bg-slate-100 border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-emerald-700 shrink-0" />
          <div>
            <strong className="block font-bold">
              {supabaseConnected && isLoggedIn
                ? 'حفظ سحابي حقيقي في جدول listings'
                : !isLoggedIn
                ? 'سجل دخولك لحفظ الإعلان في حسابك بقاعدة البيانات'
                : 'Supabase بانتظار إدخال المفتاح العام (Publishable Key)'}
            </strong>
            <span className="text-[10px] text-slate-500">
              {supabaseConnected && isLoggedIn
                ? `سيتم ربط seller_id برقم حسابك: ${supabaseUser?.id.slice(0, 8)}... وتخزين الصور في listing-images`
                : 'اضغط لتسجيل الدخول أو ضبط المفتاح'}
            </span>
          </div>
        </div>

        {!isLoggedIn ? (
          <button
            onClick={() => navigate('auth_login')}
            className="px-3 py-1.5 bg-emerald-800 text-white rounded-xl text-xs font-bold shrink-0 flex items-center gap-1"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>تسجيل دخول</span>
          </button>
        ) : !supabaseConnected ? (
          <button
            onClick={() => setIsSupabaseModalOpen(true)}
            className="px-3 py-1.5 bg-slate-800 text-white rounded-xl text-xs font-bold shrink-0"
          >
            ضبط المفتاح
          </button>
        ) : null}
      </div>

      {successMessage && (
        <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-4 mb-4 text-emerald-900 shadow-sm flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
          <div>
            <h4 className="font-black text-sm">تم نشر الإعلان بنجاح!</h4>
            <p className="text-xs text-emerald-700">تم حفظ السجلات وتوجيهك لصفحة العرض الآن...</p>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 mb-4 text-xs text-rose-700 font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Photos Picker Section with Storage upload support */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-emerald-700" />
              <span>صور الإعلان (مخزن listing-images)</span>
            </label>
            <span className="text-[11px] text-slate-400">
              {previewUrls.length + presetUrls.length}/5 صور
            </span>
          </div>

          {/* Hidden File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Photos row */}
          <div className="flex gap-2.5 overflow-x-auto pb-1">
            {/* Real local file previews */}
            {previewUrls.map((url, idx) => (
              <div
                key={`file-${idx}`}
                className="relative w-20 h-20 rounded-xl overflow-hidden border border-emerald-300 shrink-0 group"
              >
                <img src={url} alt="" className="w-full h-full object-cover" />
                <span className="absolute bottom-1 right-1 bg-emerald-800/80 text-white text-[8px] px-1 rounded">
                  ملف حقيقي
                </span>
                <button
                  type="button"
                  onClick={() => handleRemoveImage(idx, true)}
                  className="absolute top-1 left-1 w-5 h-5 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-rose-600 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}

            {/* Presets */}
            {presetUrls.map((url, idx) => (
              <div
                key={`preset-${idx}`}
                className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 shrink-0 group"
              >
                <img src={url} alt="" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => handleRemoveImage(idx, false)}
                  className="absolute top-1 left-1 w-5 h-5 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-rose-600 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}

            {previewUrls.length + presetUrls.length < 5 && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-20 h-20 rounded-xl border-2 border-dashed border-emerald-400/70 hover:border-emerald-600 bg-emerald-50/50 hover:bg-emerald-50 flex flex-col items-center justify-center text-emerald-800 text-[10px] font-bold gap-1 transition-colors shrink-0 cursor-pointer"
              >
                <Upload className="w-5 h-5 text-emerald-700" />
                <span>رفع من الجهاز</span>
              </button>
            )}
          </div>

          {/* Quick preset samples */}
          <div className="pt-2 border-t border-slate-100">
            <span className="text-[11px] text-slate-500 block mb-1.5 font-medium">
              أو اختر نماذج صور جاهزة للتجربة:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_IMAGE_PRESETS.map((preset, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleAddSampleImage(preset.url)}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-900 text-slate-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <ImageIcon className="w-3 h-3" />
                  <span>+ {preset.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-emerald-700" />
            <span>عنوان الإعلان *</span>
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثال: تويوتا هايلوكس 2021 دبل بحالة الوكالة"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
            required
          />
        </div>

        {/* Category & Subcategory */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Tag className="w-4 h-4 text-emerald-700" />
            <span>القسم والتصنيف *</span>
          </label>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[11px] text-slate-500 block mb-1">القسم الرئيسي:</span>
              <select
                value={categoryId}
                onChange={(e) => {
                  setCategoryId(e.target.value);
                  const newCat = CATEGORIES.find((c) => c.id === e.target.value);
                  if (newCat && newCat.subcategories.length > 0) {
                    setSubCategory(newCat.subcategories[0]);
                  }
                }}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-emerald-700/30"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nameAr}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">النوع الفرعي:</span>
              <select
                value={subCategory}
                onChange={(e) => setSubCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-emerald-700/30"
              >
                {currentCategory.subcategories.map((sub, i) => (
                  <option key={i} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Price & Negotiation */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <DollarSign className="w-4 h-4 text-emerald-700" />
            <span>السعر بالجنيه السوداني (ج.س) *</span>
          </label>

          <div className="relative">
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="مثال: 15000000"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-base font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 font-mono"
              required
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-emerald-700">
              جنيه سوداني
            </span>
          </div>

          <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
            <input
              type="checkbox"
              checked={isNegotiable}
              onChange={(e) => setIsNegotiable(e.target.checked)}
              className="w-4 h-4 text-emerald-800 rounded border-slate-300 focus:ring-emerald-700 accent-emerald-800"
            />
            <span className="text-xs text-slate-700 font-semibold">
              السعر قابل للتفاوض مع المشتري الجاد
            </span>
          </label>
        </div>

        {/* City and District */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
          <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-emerald-700" />
            <span>موقع السلعة *</span>
          </label>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[11px] text-slate-500 block mb-1">المدينة:</span>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-emerald-700/30"
              >
                {CITIES.filter((c) => c.id !== 'all').map((c) => (
                  <option key={c.id} value={c.nameAr}>
                    {c.nameAr} ({c.region})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="text-[11px] text-slate-500 block mb-1">الحي أو المنطقة:</span>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="مثال: حي الشاطئ"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-700/30"
              />
            </div>
          </div>
        </div>

        {/* Detailed Description */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
          <label className="block text-xs font-bold text-slate-800">
            الوصف والمعلومات الإضافية *
          </label>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="اذكر حالة السلعة، مدة الاستخدام، سبب البيع، وأي تفاصيل أخرى تساعد المشتري..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 leading-relaxed"
            required
          />
        </div>

        {/* Contact info */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
          <label className="block text-xs font-bold text-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-emerald-700" />
              <span>{t('contactSection')}</span>
            </span>
            {effectivePhone.trim() !== '' && (
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                phoneValidation.isValid ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {phoneValidation.isValid ? '✓ رقم سوداني معتمد' : 'غير مكتمل'}
              </span>
            )}
          </label>

          {/* If user has account phone, offer choice */}
          {hasAccountPhone && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setUseAccountPhone(true)}
                className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                  useAccountPhone
                    ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 shadow-2xs'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                  useAccountPhone ? 'border-emerald-700 bg-emerald-700' : 'border-slate-300'
                }`}>
                  {useAccountPhone && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
                <div className="text-right flex-1 truncate">
                  <span className="block text-[11px] font-bold">{t('useAccountPhone')}</span>
                  <span className="text-[10px] font-mono text-emerald-800 dir-ltr block">{formatDisplayPhone(user?.phone || '')}</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setUseAccountPhone(false)}
                className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                  !useAccountPhone
                    ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 shadow-2xs'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                  !useAccountPhone ? 'border-emerald-700 bg-emerald-700' : 'border-slate-300'
                }`}>
                  {!useAccountPhone && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
                <div className="text-right flex-1 truncate">
                  <span className="block text-[11px] font-bold">{t('useCustomPhone')}</span>
                  <span className="text-[10px] text-slate-400 block">إدخال رقم هاتف آخر</span>
                </div>
              </button>
            </div>
          )}

          {/* Custom phone input field */}
          {(!hasAccountPhone || !useAccountPhone) && (
            <div className="space-y-1.5 pt-1">
              <input
                type="tel"
                value={customPhone}
                onChange={(e) => setCustomPhone(e.target.value)}
                placeholder={t('contactPhonePlaceholder')}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
                dir="ltr"
                required
              />
              <p className="text-[10px] text-slate-400">
                {t('phoneHintSudan')}
              </p>
            </div>
          )}

          {effectivePhone.trim() !== '' && (
            <div className="text-[11px] pt-1">
              {phoneValidation.isValid ? (
                <div className="text-emerald-700 flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>الصيغة المعتمدة للاتصال والواتساب: </span>
                  <strong className="font-mono dir-ltr">{phoneValidation.international}</strong>
                </div>
              ) : (
                <div className="text-rose-600 flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{language === 'ar' ? phoneValidation.errorAr : phoneValidation.errorEn}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white py-4 rounded-2xl font-bold text-sm shadow-md shadow-emerald-900/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{submissionProgress || 'جاري الحفظ في قاعدة البيانات...'}</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                <span>نشر الإعلان الآن</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
