import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Phone, 
  Lock, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  UserPlus, 
  LogIn, 
  KeyRound,
  Mail,
  Loader2,
  Database
} from 'lucide-react';

interface AuthScreenProps {
  initialMode?: 'login' | 'register';
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ initialMode = 'login' }) => {
  const { 
    signInWithSupabase, 
    signUpWithSupabase, 
    supabaseConnected, 
    setIsSupabaseModalOpen,
    navigate 
  } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [identifier, setIdentifier] = useState('912345678');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!identifier.trim()) {
      setError('يرجى إدخال رقم الهاتف أو البريد الإلكتروني');
      return;
    }

    if (!password || password.length < 6) {
      setError('كلمة المرور يجب ألا تقل عن 6 أحرف أو أرقام');
      return;
    }

    if (mode === 'register' && !name.trim()) {
      setError('يرجى إدخال اسمك الشخصي أو اسم المتجر');
      return;
    }

    if (!supabaseConnected) {
      setError('يجب تفعيل مفتاح Supabase أولاً لتسجيل الحسابات الحقيقية.');
      setIsSupabaseModalOpen(true);
      return;
    }

    setLoading(true);

    if (mode === 'register') {
      const result = await signUpWithSupabase(identifier, password, name, identifier);
      setLoading(false);
      if (result.success) {
        setSuccess('تم إنشاء حسابك بنجاح في Supabase! جاري توجيهك...');
        setTimeout(() => navigate('profile'), 1200);
      } else {
        setError(result.error || 'فشلت عملية إنشاء الحساب');
      }
    } else {
      const result = await signInWithSupabase(identifier, password);
      setLoading(false);
      if (result.success) {
        setSuccess('تم تسجيل الدخول بنجاح! جاري توجيهك...');
        setTimeout(() => navigate('profile'), 1000);
      } else {
        setError(result.error || 'بيانات الدخول غير صحيحة');
      }
    }
  };

  return (
    <div className="pb-12 px-4 pt-4 bg-slate-50 min-h-screen" dir="rtl">
      {/* Supabase connection indicator banner */}
      <div className={`rounded-2xl p-3 mb-4 text-xs flex items-center justify-between border ${
        supabaseConnected 
          ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
          : 'bg-amber-50 border-amber-200 text-amber-900'
      }`}>
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>
            {supabaseConnected 
              ? 'مصادقة Supabase Auth مفعلة وجاهزة للحسابات الحقيقية' 
              : 'Supabase بانتظار إدخال المفتاح العام (Publishable Key)'}
          </span>
        </div>
        <button
          onClick={() => setIsSupabaseModalOpen(true)}
          className="text-xs font-bold underline shrink-0 mr-2"
        >
          {supabaseConnected ? 'الإعدادات' : 'إدخال المفتاح'}
        </button>
      </div>

      <div className="max-w-md mx-auto bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        {/* Logo and Welcome */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-emerald-800 text-white font-black text-2xl flex items-center justify-center mx-auto mb-3 shadow-md shadow-emerald-900/20">
            س
          </div>
          <h2 className="text-xl font-black text-slate-900">
            {mode === 'login' ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب جديد في سوق السودان'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {mode === 'login'
              ? 'أدخل بيانات حسابك الموثق في قاعدة بيانات Supabase'
              : 'سجل حسابك لحفظ إعلاناتك والتواصل المباشر مع المشترين'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl mb-5">
          <button
            onClick={() => {
              setMode('login');
              setError('');
              setSuccess('');
            }}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'login' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-500'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            onClick={() => {
              setMode('register');
              setError('');
              setSuccess('');
            }}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'register' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-500'
            }`}
          >
            حساب جديد
          </button>
        </div>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 mb-4 text-xs text-rose-700 font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-4 text-xs text-emerald-800 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                الاسم الكامل أو اسم المتجر
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: عثمان عبد الله الفكي"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
                required
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              رقم الهاتف أو البريد الإلكتروني
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-200/70 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Phone className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="912345678 أو email@example.com"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none dir-ltr text-right"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              يمكنك كتابة رقم الهاتف السوداني أو بريدك الإلكتروني
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              كلمة المرور
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-200/70 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white py-3.5 rounded-2xl font-bold text-sm shadow-md shadow-emerald-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري المعالجة في Supabase...</span>
              </>
            ) : mode === 'login' ? (
              <>
                <LogIn className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>إنشاء الحساب</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-100 text-center">
          <button
            onClick={() => navigate('home')}
            className="text-xs text-slate-500 hover:text-emerald-800 font-bold"
          >
            تخطي ومتابعة التصفح كزائر
          </button>
        </div>
      </div>
    </div>
  );
};
