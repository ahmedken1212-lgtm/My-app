import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bell, 
  Globe, 
  Coins, 
  Shield, 
  FileText, 
  Check, 
  ChevronLeft,
  ChevronRight,
  User,
  CheckCircle2
} from 'lucide-react';

export const SettingsScreen: React.FC = () => {
  const { 
    navigate, 
    language, 
    setLanguage, 
    isLoggedIn, 
    user, 
    t, 
    isRtl 
  } = useApp();

  const [pushNotifs, setPushNotifs] = useState(true);
  const [whatsappAlerts, setWhatsappAlerts] = useState(true);

  const ChevronIcon = isRtl ? ChevronLeft : ChevronRight;

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* App identity card */}
      <div className="bg-gradient-to-l from-emerald-800 to-emerald-900 rounded-3xl p-4 text-white shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-xl">
            س
          </div>
          <div>
            <h3 className="font-extrabold text-base">{t('appName')}</h3>
            <p className="text-xs text-emerald-100">{t('appVersion')}</p>
          </div>
        </div>
      </div>

      {/* Account Settings Shortcut (if logged in) */}
      {isLoggedIn && (
        <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 shadow-xs">
          <div className="p-3.5 bg-slate-50 font-bold text-xs text-slate-500">
            {t('navAccountSettings')}
          </div>
          <button
            onClick={() => navigate('account_settings')}
            className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 text-slate-800 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <User className="w-4 h-4" />
              </div>
              <div className={isRtl ? 'text-right' : 'text-left'}>
                <span className="text-xs font-bold block">{t('accountSettingsTitle')}</span>
                <span className="text-[10px] text-slate-400">{user?.name} ({user?.phone || user?.email || ''})</span>
              </div>
            </div>
            <ChevronIcon className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      )}

      {/* Language Section */}
      <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 shadow-xs">
        <div className="p-3.5 bg-slate-50 font-bold text-xs text-slate-500 flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-700" />
          <span>{t('languageSection')}</span>
        </div>

        <div className="p-3 space-y-2">
          <button
            onClick={() => setLanguage('ar')}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
              language === 'ar'
                ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold shadow-2xs'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-bold">العربية (Arabic)</span>
              <span className="text-[11px] text-slate-400">اللغة الافتراضية • RTL</span>
            </div>
            {language === 'ar' && (
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            )}
          </button>

          <button
            onClick={() => setLanguage('en')}
            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
              language === 'en'
                ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold shadow-2xs'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-bold">English (الإنجليزية)</span>
              <span className="text-[11px] text-slate-400">English • LTR</span>
            </div>
            {language === 'en' && (
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            )}
          </button>
        </div>
      </div>

      {/* Notification Preferences */}
      <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 shadow-xs">
        <div className="p-3.5 bg-slate-50 font-bold text-xs text-slate-500 flex items-center gap-2">
          <Bell className="w-4 h-4 text-emerald-700" />
          <span>{t('preferencesSection')}</span>
        </div>

        <div className="p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4 text-emerald-700" />
            <div>
              <span className="text-xs font-bold text-slate-800 block">{t('pushNotifications')}</span>
              <span className="text-[10px] text-slate-400">{t('pushNotificationsDesc')}</span>
            </div>
          </div>
          <input
            type="checkbox"
            checked={pushNotifs}
            onChange={(e) => setPushNotifs(e.target.checked)}
            className="w-4 h-4 text-emerald-800 rounded accent-emerald-800 cursor-pointer"
          />
        </div>

        <div className="p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Globe className="w-4 h-4 text-emerald-700" />
            <div>
              <span className="text-xs font-bold text-slate-800 block">{t('whatsappAlerts')}</span>
              <span className="text-[10px] text-slate-400">{t('whatsappAlertsDesc')}</span>
            </div>
          </div>
          <input
            type="checkbox"
            checked={whatsappAlerts}
            onChange={(e) => setWhatsappAlerts(e.target.checked)}
            className="w-4 h-4 text-emerald-800 rounded accent-emerald-800 cursor-pointer"
          />
        </div>

        <div className="p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Coins className="w-4 h-4 text-emerald-700" />
            <span className="text-xs font-bold text-slate-800">{t('currencyLabel')}</span>
          </div>
          <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg">
            {t('priceSdg')}
          </span>
        </div>
      </div>

      {/* Legal & Policies */}
      <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 shadow-xs">
        <div className="p-3.5 bg-slate-50 font-bold text-xs text-slate-500">
          {t('supportSection')}
        </div>

        <button
          onClick={() => navigate('privacy_policy')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-emerald-700" />
            <span className="text-xs font-bold">{t('privacyPolicy')}</span>
          </div>
          <ChevronIcon className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => navigate('terms_of_service')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <FileText className="w-4 h-4 text-emerald-700" />
            <span className="text-xs font-bold">{t('termsOfService')}</span>
          </div>
          <ChevronIcon className="w-4 h-4 text-slate-400" />
        </button>
      </div>
    </div>
  );
};
