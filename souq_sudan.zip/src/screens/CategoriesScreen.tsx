import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/mockData';
import { 
  Car, 
  Building, 
  Smartphone, 
  Armchair, 
  Refrigerator, 
  Shirt, 
  Briefcase, 
  Wrench,
  ChevronLeft,
  Search,
  Sparkles
} from 'lucide-react';

const categoryIcons: Record<string, React.ElementType> = {
  cars: Car,
  real_estate: Building,
  phones_electronics: Smartphone,
  furniture: Armchair,
  appliances: Refrigerator,
  clothing: Shirt,
  jobs: Briefcase,
  services: Wrench,
};

export const CategoriesScreen: React.FC = () => {
  const { navigate, setFilters } = useApp();
  const [selectedCatId, setSelectedCatId] = useState<string>(CATEGORIES[0].id);
  const [searchCategoryQuery, setSearchCategoryQuery] = useState('');

  const activeCategory = CATEGORIES.find((c) => c.id === selectedCatId) || CATEGORIES[0];

  const filteredCategories = CATEGORIES.filter((c) =>
    c.nameAr.includes(searchCategoryQuery.trim()) ||
    c.subcategories.some((sub) => sub.includes(searchCategoryQuery.trim()))
  );

  const handleSelectSubcategory = (categoryId: string, subcategoryName?: string) => {
    setFilters((prev) => ({
      ...prev,
      categoryId,
      query: subcategoryName || '',
    }));
    navigate('search');
  };

  return (
    <div className="space-y-4 pb-6 px-4">
      {/* Search Input for categories */}
      <div className="pt-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchCategoryQuery}
            onChange={(e) => setSearchCategoryQuery(e.target.value)}
            placeholder="ابحث في الأقسام والأصناف الفرعية..."
            className="w-full bg-white border border-slate-200 text-slate-800 text-sm rounded-2xl pr-10 pl-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 focus:border-emerald-700 transition-all shadow-2xs"
          />
        </div>
      </div>

      {/* Categories layout: Two-column master-detail style for mobile or tablet */}
      <div className="grid grid-cols-12 gap-3">
        {/* Left Side: Category Tabs */}
        <div className="col-span-5 space-y-2">
          {filteredCategories.map((cat) => {
            const Icon = categoryIcons[cat.id] || Sparkles;
            const isSelected = cat.id === activeCategory.id;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCatId(cat.id)}
                className={`w-full flex items-center gap-2.5 p-3 rounded-2xl text-right transition-all ${
                  isSelected
                    ? 'bg-emerald-800 text-white font-bold shadow-md shadow-emerald-950/20'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-100 font-medium'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <span className="text-xs block truncate">{cat.nameAr}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Side: Active Category Subcategories */}
        <div className="col-span-7 bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">
                  {activeCategory.nameAr}
                </h3>
                <span className="text-[11px] text-emerald-700 font-semibold">
                  {activeCategory.listingsCount}+ إعلان معروض
                </span>
              </div>
              <button
                onClick={() => handleSelectSubcategory(activeCategory.id)}
                className="text-xs text-emerald-800 font-bold bg-emerald-50 px-2.5 py-1 rounded-xl hover:bg-emerald-100 transition-colors"
              >
                تصفح الكل
              </button>
            </div>

            <div className="space-y-1.5">
              {activeCategory.subcategories.map((sub, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectSubcategory(activeCategory.id, sub)}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-emerald-50/70 text-slate-700 hover:text-emerald-900 text-xs font-medium text-right transition-colors group"
                >
                  <span className="group-hover:translate-x-[-2px] transition-transform">
                    {sub}
                  </span>
                  <ChevronLeft className="w-4 h-4 text-slate-300 group-hover:text-emerald-700" />
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={() => handleSelectSubcategory(activeCategory.id)}
              className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl transition-colors text-center shadow-xs"
            >
              عرض كافة إعلانات {activeCategory.nameAr}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
