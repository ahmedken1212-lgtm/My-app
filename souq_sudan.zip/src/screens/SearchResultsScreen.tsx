import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CITIES } from '../data/mockData';
import { ListingCard } from '../components/ListingCard';
import { LoadingSkeleton, EmptyState, ErrorState } from '../components/StateFeedback';
import { 
  Search, 
  SlidersHorizontal, 
  X, 
  MapPin, 
  Tag, 
  ArrowUpDown,
  Filter,
  Check
} from 'lucide-react';

export const SearchResultsScreen: React.FC = () => {
  const { 
    allListings, 
    filters, 
    setFilters, 
    resetFilters,
    simulatedState,
    setSimulatedState
  } = useApp();

  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [localQuery, setLocalQuery] = useState(filters.query);

  // Temporary local filter states inside modal
  const [tempCategory, setTempCategory] = useState(filters.categoryId);
  const [tempCity, setTempCity] = useState(filters.city);
  const [tempMinPrice, setTempMinPrice] = useState(filters.minPrice?.toString() || '');
  const [tempMaxPrice, setTempMaxPrice] = useState(filters.maxPrice?.toString() || '');
  const [tempSortBy, setTempSortBy] = useState(filters.sortBy);

  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setFilters((prev) => ({ ...prev, query: localQuery }));
  };

  const applyFilters = () => {
    setFilters({
      query: localQuery,
      categoryId: tempCategory,
      city: tempCity,
      minPrice: tempMinPrice ? parseFloat(tempMinPrice) : undefined,
      maxPrice: tempMaxPrice ? parseFloat(tempMaxPrice) : undefined,
      sortBy: tempSortBy,
    });
    setIsFilterSheetOpen(false);
  };

  // Perform search and filtering
  const filteredListings = allListings.filter((listing) => {
    // Query search
    if (filters.query) {
      const q = filters.query.toLowerCase().trim();
      const matchesTitle = listing.title.toLowerCase().includes(q);
      const matchesDesc = listing.description.toLowerCase().includes(q);
      const matchesSub = listing.subCategory?.toLowerCase().includes(q);
      if (!matchesTitle && !matchesDesc && !matchesSub) return false;
    }

    // Category filter
    if (filters.categoryId && filters.categoryId !== 'all') {
      if (listing.categoryId !== filters.categoryId) return false;
    }

    // City filter
    if (filters.city && filters.city !== 'all') {
      const cityObj = CITIES.find((c) => c.id === filters.city);
      if (cityObj && !listing.city.includes(cityObj.nameAr)) return false;
    }

    // Min price
    if (filters.minPrice !== undefined && listing.price < filters.minPrice) {
      return false;
    }

    // Max price
    if (filters.maxPrice !== undefined && listing.price > filters.maxPrice) {
      return false;
    }

    return true;
  });

  // Sort
  const sortedListings = [...filteredListings].sort((a, b) => {
    if (filters.sortBy === 'price_asc') {
      return a.price - b.price;
    }
    if (filters.sortBy === 'price_desc') {
      return b.price - a.price;
    }
    // Default latest
    return 0;
  });

  const activeCategoryObj = CATEGORIES.find((c) => c.id === filters.categoryId);
  const activeCityObj = CITIES.find((c) => c.id === filters.city);

  const hasActiveFilters =
    filters.categoryId !== 'all' ||
    filters.city !== 'all' ||
    filters.minPrice !== undefined ||
    filters.maxPrice !== undefined;

  return (
    <div className="space-y-4 pb-6 px-4">
      {/* Search Input and Filter Trigger */}
      <form onSubmit={handleSearchSubmit} className="pt-3 flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            placeholder="اكتب كلمة البحث..."
            className="w-full bg-white border border-slate-200 text-slate-800 text-sm rounded-2xl pr-10 pl-8 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 focus:border-emerald-700 transition-all shadow-2xs"
          />
          {localQuery && (
            <button
              type="button"
              onClick={() => {
                setLocalQuery('');
                setFilters((prev) => ({ ...prev, query: '' }));
              }}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => {
            setTempCategory(filters.categoryId);
            setTempCity(filters.city);
            setTempMinPrice(filters.minPrice?.toString() || '');
            setTempMaxPrice(filters.maxPrice?.toString() || '');
            setTempSortBy(filters.sortBy);
            setIsFilterSheetOpen(true);
          }}
          className={`px-4 rounded-2xl flex items-center justify-center gap-1.5 text-sm font-bold transition-all shrink-0 cursor-pointer ${
            hasActiveFilters
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>فلترة</span>
          {hasActiveFilters && (
            <span className="w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>
      </form>

      {/* Active Filter Chips */}
      {hasActiveFilters && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {activeCategoryObj && (
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs px-2.5 py-1 rounded-full font-medium shrink-0">
              <Tag className="w-3 h-3" />
              <span>{activeCategoryObj.nameAr}</span>
              <button
                onClick={() => setFilters((prev) => ({ ...prev, categoryId: 'all' }))}
                className="hover:text-emerald-950 mr-1"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {activeCityObj && activeCityObj.id !== 'all' && (
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs px-2.5 py-1 rounded-full font-medium shrink-0">
              <MapPin className="w-3 h-3" />
              <span>{activeCityObj.nameAr}</span>
              <button
                onClick={() => setFilters((prev) => ({ ...prev, city: 'all' }))}
                className="hover:text-emerald-950 mr-1"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {(filters.minPrice || filters.maxPrice) && (
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs px-2.5 py-1 rounded-full font-medium shrink-0">
              <span>
                السعر: {filters.minPrice || '0'} - {filters.maxPrice || 'الكل'} ج.س
              </span>
              <button
                onClick={() =>
                  setFilters((prev) => ({ ...prev, minPrice: undefined, maxPrice: undefined }))
                }
                className="hover:text-emerald-950 mr-1"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          <button
            onClick={resetFilters}
            className="text-xs text-rose-600 hover:underline shrink-0 mr-auto font-medium"
          >
            مسح الكل
          </button>
        </div>
      )}

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
        <span>
          تم العثور على <strong className="text-slate-800 font-bold">{sortedListings.length}</strong> إعلان
        </span>

        {/* Quick sort toggle */}
        <div className="flex items-center gap-1">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={filters.sortBy}
            onChange={(e) =>
              setFilters((prev) => ({
                ...prev,
                sortBy: e.target.value as 'latest' | 'price_asc' | 'price_desc',
              }))
            }
            className="bg-transparent border-0 text-slate-700 font-bold text-xs focus:ring-0 cursor-pointer"
          >
            <option value="latest">الأحدث تاريخاً</option>
            <option value="price_asc">الأقل سعراً</option>
            <option value="price_desc">الأعلى سعراً</option>
          </select>
        </div>
      </div>

      {/* Results List */}
      {simulatedState === 'loading' ? (
        <LoadingSkeleton count={4} />
      ) : simulatedState === 'error' ? (
        <ErrorState onRetry={() => setSimulatedState('normal')} />
      ) : sortedListings.length === 0 ? (
        <EmptyState
          title="لم يتم العثور على نتائج مطابقة"
          description="حاول تعديل كلمات البحث، أو إزالة بعض الفلاتر والأسعار لتوسيع نطاق البحث."
          actionText="إعادة ضبط الفلاتر"
          onAction={resetFilters}
        />
      ) : (
        <div className="space-y-3">
          {sortedListings.map((item) => (
            <ListingCard key={item.id} listing={item} layout="horizontal" />
          ))}
        </div>
      )}

      {/* Filter Bottom Sheet Modal */}
      {isFilterSheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div 
            className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
            dir="rtl"
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-emerald-800" />
                <h3 className="font-bold text-slate-900 text-base">فلترة البحث وتخصيصه</h3>
              </div>
              <button
                onClick={() => setIsFilterSheetOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-200 text-slate-600 flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4 overflow-y-auto flex-1">
              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  القسم المطلوب
                </label>
                <select
                  value={tempCategory}
                  onChange={(e) => setTempCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:ring-2 focus:ring-emerald-700/30"
                >
                  <option value="all">كافة الأقسام</option>
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  المدينة أو الولاية
                </label>
                <select
                  value={tempCity}
                  onChange={(e) => setTempCity(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm text-slate-800 focus:ring-2 focus:ring-emerald-700/30"
                >
                  {CITIES.map((city) => (
                    <option key={city.id} value={city.id}>
                      {city.nameAr} ({city.region})
                    </option>
                  ))}
                </select>
              </div>

              {/* Price range */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  نطاق السعر بالجنيه السوداني (ج.س)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <input
                      type="number"
                      placeholder="أدنى سعر"
                      value={tempMinPrice}
                      onChange={(e) => setTempMinPrice(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-sm text-slate-800 focus:ring-2 focus:ring-emerald-700/30"
                    />
                  </div>
                  <div>
                    <input
                      type="number"
                      placeholder="أعلى سعر"
                      value={tempMaxPrice}
                      onChange={(e) => setTempMaxPrice(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-sm text-slate-800 focus:ring-2 focus:ring-emerald-700/30"
                    />
                  </div>
                </div>
              </div>

              {/* Sort By */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  ترتيب النتائج حسب
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'latest', label: 'الأحدث' },
                    { id: 'price_asc', label: 'الأقل سعراً' },
                    { id: 'price_desc', label: 'الأعلى سعراً' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setTempSortBy(opt.id as any)}
                      className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                        tempSortBy === opt.id
                          ? 'bg-emerald-800 text-white border-emerald-800'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setTempCategory('all');
                  setTempCity('all');
                  setTempMinPrice('');
                  setTempMaxPrice('');
                  setTempSortBy('latest');
                }}
                className="py-3 px-4 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition-colors"
              >
                مسح
              </button>
              <button
                type="button"
                onClick={applyFilters}
                className="flex-1 py-3 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white text-sm font-bold rounded-xl transition-colors shadow-xs"
              >
                تطبيق الفلاتر
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
