import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ListingCard } from '../components/ListingCard';
import { UserAvatar } from '../components/UserAvatar';
import { 
  User, 
  Settings, 
  Bell, 
  Shield, 
  HelpCircle, 
  LogOut, 
  PlusCircle, 
  Heart, 
  FileText, 
  CheckCircle2, 
  Phone, 
  MapPin,
  ChevronLeft,
  Database
} from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const { 
    user, 
    isLoggedIn, 
    logoutUser, 
    navigate, 
    userListings, 
    favorites, 
    allListings,
    supabaseConnected,
    setIsSupabaseModalOpen,
    t,
    isRtl
  } = useApp();

  const [activeTab, setActiveTab] = useState<'my_listings' | 'favorites'>('my_listings');
  const ChevronIcon = isRtl ? ChevronLeft : ChevronRight;

  if (!isLoggedIn || !user) {
    return (
      <div className="p-6 text-center max-w-sm mx-auto my-12" dir="rtl">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto mb-4">
          <User className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-slate-800 mb-1">تسجيل الدخول إلى حسابك</h3>
        <p className="text-xs text-slate-500 mb-6">
          سجل دخولك لتتمكن من إضافة إعلاناتك، متابعة المفضلة، والتواصل السريع مع المشترين.
        </p>
        <div className="space-y-2.5">
          <button
            onClick={() => navigate('auth_login')}
            className="w-full py-3.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-2xl text-sm font-bold shadow-md shadow-emerald-900/20"
          >
            تسجيل الدخول إلى حسابك
          </button>
          <button
            onClick={() => navigate('auth_register')}
            className="w-full py-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-2xl text-sm font-bold border border-emerald-200"
          >
            إنشاء حساب جديد مجاناً
          </button>
        </div>
      </div>
    );
  }

  const favoriteListings = allListings.filter((l) => favorites.includes(l.id));

  return (
    <div className="pb-16 px-4 pt-3 space-y-4 bg-slate-50 min-h-screen" dir="rtl">
      {/* User Info Card */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="relative shrink-0">
            <UserAvatar
              name={user.name}
              avatarUrl={user.avatarUrl}
              size="lg"
              fallbackType="letter_s"
              className="w-14 h-14 rounded-2xl"
            />
            {user.verified && (
              <span className="absolute -bottom-1 -left-1 bg-emerald-700 text-white p-0.5 rounded-full ring-2 ring-white">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            )}
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="font-black text-slate-900 text-base">{user.name}</h3>
              {user.verified && (
                <span className="text-[10px] bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  موثق
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span className="font-mono dir-ltr">{user.phone}</span>
              <span>• {user.city}</span>
            </div>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              عضو منذ {user.joinDate}
            </span>
          </div>
        </div>

        {/* Quick actions row */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100">
          <button
            onClick={() => navigate('create_listing')}
            className="flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-800 text-white rounded-xl text-xs font-bold hover:bg-emerald-900 transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>نشر إعلان جديد</span>
          </button>
          <button
            onClick={() => navigate('account_settings')}
            className="flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4" />
            <span>{t('accountSettingsTitle')}</span>
          </button>
        </div>
      </div>

      {/* Tabs: My Listings vs Favorites */}
      <div>
        <div className="grid grid-cols-2 p-1 bg-slate-200/80 rounded-2xl mb-3">
          <button
            onClick={() => setActiveTab('my_listings')}
            className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'my_listings'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-slate-600'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>إعلاناتي ({userListings.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('favorites')}
            className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'favorites'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-slate-600'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>المفضلة ({favoriteListings.length})</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'my_listings' ? (
          <div>
            {userListings.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center border border-slate-100">
                <p className="text-xs text-slate-500 mb-3">لم تقم بنشر أي إعلانات بعد.</p>
                <button
                  onClick={() => navigate('create_listing')}
                  className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-bold"
                >
                  أضف أول إعلان الآن
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {userListings.map((item) => (
                  <div key={item.id} className="relative">
                    <ListingCard listing={item} layout="horizontal" />
                    <span className="absolute top-2 left-2 bg-emerald-700 text-white text-[9px] font-bold px-2 py-0.5 rounded-full z-10 shadow-xs">
                      نشط ومعروض
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div>
            {favoriteListings.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center border border-slate-100">
                <p className="text-xs text-slate-500 mb-3">قائمة المفضلة فارغة حالياً.</p>
                <button
                  onClick={() => navigate('home')}
                  className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-bold"
                >
                  تصفح الإعلانات المميزة
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {favoriteListings.map((item) => (
                  <ListingCard key={item.id} listing={item} layout="horizontal" />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Settings & Links List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 text-xs font-medium">
        <button
          onClick={() => navigate('notifications')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-700"
        >
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4 text-emerald-700" />
            <span>الإشعارات والتنبيهات</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => navigate('privacy_policy')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-700"
        >
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-emerald-700" />
            <span>سياسة الخصوصية وأمان المعاملات</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => navigate('terms_of_service')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-700"
        >
          <div className="flex items-center gap-2.5">
            <FileText className="w-4 h-4 text-emerald-700" />
            <span>شروط الاستخدام واتفاقية الوساطة</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => navigate('settings')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-700"
        >
          <div className="flex items-center gap-2.5">
            <Settings className="w-4 h-4 text-emerald-700" />
            <span>الإعدادات العامة للتطبيق</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => setIsSupabaseModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors text-slate-700"
        >
          <div className="flex items-center gap-2.5">
            <Database className="w-4 h-4 text-emerald-700" />
            <span>حالة ربط قاعدة بيانات Supabase</span>
          </div>
          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full">
            {supabaseConnected ? 'متصل' : 'بانتظار المفتاح'}
          </span>
        </button>

        <button
          onClick={logoutUser}
          className="w-full p-3.5 flex items-center justify-between hover:bg-rose-50 transition-colors text-rose-600 font-bold"
        >
          <div className="flex items-center gap-2.5">
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج من الحساب</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-rose-400" />
        </button>
      </div>
    </div>
  );
};
