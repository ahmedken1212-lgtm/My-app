import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { validateSudanPhoneNumber, formatDisplayPhone } from '../lib/phoneUtils';
import { 
  Phone, 
  MessageCircle, 
  MapPin, 
  Clock, 
  Eye, 
  Heart, 
  Share2, 
  ShieldAlert, 
  CheckCircle2, 
  Star, 
  ChevronRight, 
  ChevronLeft, 
  ArrowRight,
  ArrowLeft,
  Calendar, 
  Layers, 
  Flag,
  AlertCircle,
  X
} from 'lucide-react';

export const ListingDetailScreen: React.FC = () => {
  const { selectedListing, isFavorite, toggleFavorite, navigate, t, isRtl, language } = useApp();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [contactErrorModal, setContactErrorModal] = useState<string | null>(null);

  if (!selectedListing) {
    return (
      <div className="p-8 text-center" dir={isRtl ? 'rtl' : 'ltr'}>
        <p className="text-slate-600 mb-4">{t('emptyListingsTitle')}</p>
        <button
          onClick={() => navigate('home')}
          className="px-4 py-2 bg-emerald-800 text-white rounded-xl text-sm font-bold cursor-pointer"
        >
          {t('navHome')}
        </button>
      </div>
    );
  }

  const favorite = isFavorite(selectedListing.id);
  const formattedPrice = new Intl.NumberFormat(language === 'ar' ? 'ar-SD' : 'en-US').format(selectedListing.price);

  const images = selectedListing.images && selectedListing.images.length > 0 
    ? selectedListing.images 
    : ['https://images.unsplash.com/photo-1559416523-140ddc3d238c?auto=format&fit=crop&w=800&q=80'];

  // Validate seller phone number rigorously
  const rawSellerPhone = (selectedListing.seller?.phone || '').trim();
  const phoneValidation = validateSudanPhoneNumber(rawSellerPhone);

  // Handle Direct Call
  const handleCall = () => {
    if (!rawSellerPhone || !phoneValidation.isValid) {
      setContactErrorModal(t('noPhoneAvailable'));
      return;
    }
    window.location.href = `tel:${phoneValidation.international}`;
  };

  // Handle WhatsApp Link
  const handleWhatsApp = () => {
    const rawWa = (selectedListing.seller?.whatsapp || selectedListing.seller?.phone || '').trim();
    const waVal = validateSudanPhoneNumber(rawWa);

    let cleanPhone = '';
    if (waVal.isValid) {
      cleanPhone = waVal.whatsapp;
    } else if (phoneValidation.isValid) {
      cleanPhone = phoneValidation.whatsapp;
    } else {
      setContactErrorModal(t('noPhoneAvailable'));
      return;
    }

    const message = encodeURIComponent(
      language === 'ar'
        ? `السلام عليكم، أنا مهتم بإعلانك على سوق السودان:\n"${selectedListing.title}"\nهل السلعة ما زالت متوفرة؟`
        : `Hello, I am interested in your ad on Sudan Souq:\n"${selectedListing.title}"\nIs this item still available?`
    );

    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: selectedListing.title,
        text: `${selectedListing.title} - ${t('appName')}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      alert(t('copyLinkSuccess'));
    }
  };

  const BackIcon = isRtl ? ChevronRight : ChevronLeft;

  return (
    <div className="pb-24 bg-slate-50 min-h-screen" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Contact Error Modal */}
      {contactErrorModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white max-w-sm w-full rounded-3xl p-5 border border-slate-200 text-center space-y-3.5 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base">{t('errorTitle')}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {contactErrorModal}
              </p>
            </div>
            <button
              onClick={() => setContactErrorModal(null)}
              className="w-full py-3 bg-slate-900 hover:bg-black text-white font-bold rounded-2xl text-xs transition-colors cursor-pointer"
            >
              {t('confirm')}
            </button>
          </div>
        </div>
      )}

      {/* Image Gallery */}
      <div className="relative bg-slate-900 aspect-4/3 w-full overflow-hidden select-none">
        <img
          src={images[activeImageIndex]}
          alt={selectedListing.title}
          className="w-full h-full object-cover transition-all duration-300"
        />

        {/* Image index indicator */}
        {images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-white text-[11px] font-mono flex items-center gap-1.5 shadow-sm">
            <span>{activeImageIndex + 1}</span>
            <span>/</span>
            <span>{images.length}</span>
          </div>
        )}

        {/* Floating Top Controls (Back, Favorite, Share) */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          <button
            onClick={() => navigate('home')}
            className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-800 flex items-center justify-center backdrop-blur-md shadow-md transition-all active:scale-95 pointer-events-auto cursor-pointer"
            title={t('back')}
          >
            <BackIcon className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              onClick={() => toggleFavorite(selectedListing.id)}
              className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md shadow-md transition-all active:scale-95 cursor-pointer ${
                favorite 
                  ? 'bg-rose-500 text-white' 
                  : 'bg-white/80 hover:bg-white text-slate-700'
              }`}
              title={t('navFavorites')}
            >
              <Heart className={`w-5 h-5 ${favorite ? 'fill-white' : ''}`} />
            </button>

            <button
              onClick={handleShare}
              className="w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-800 flex items-center justify-center backdrop-blur-md shadow-md transition-all active:scale-95 cursor-pointer"
              title="مشاركة"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Thumbnail Navigator (if multiple images) */}
        {images.length > 1 && (
          <div className="absolute bottom-3 right-3 flex gap-1.5 overflow-x-auto max-w-[200px] p-1">
            {images.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImageIndex(i)}
                className={`w-8 h-8 rounded-lg overflow-hidden border-2 transition-all ${
                  activeImageIndex === i ? 'border-emerald-400 scale-105' : 'border-white/50 opacity-70'
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Details Card */}
      <div className="bg-white p-4 border-b border-slate-200/80 space-y-3">
        {/* Price & Status */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-emerald-800 tracking-tight">
                {formattedPrice}
              </span>
              <span className="text-sm font-bold text-emerald-700">{t('priceSdg')}</span>
            </div>
            {selectedListing.isNegotiable && (
              <span className="inline-block mt-1 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200/70 px-2.5 py-0.5 rounded-full font-bold">
                {t('negotiablePrice')}
              </span>
            )}
          </div>

          <span className="text-[11px] text-slate-400 bg-slate-100 px-2.5 py-1 rounded-lg font-mono">
            {t('adNumber')}: {selectedListing.id}
          </span>
        </div>

        {/* Title */}
        <h1 className="text-lg font-black text-slate-900 leading-snug">
          {selectedListing.title}
        </h1>

        {/* Meta badges (Location, Date, Views) */}
        <div className="flex items-center gap-3 text-xs text-slate-500 pt-1 flex-wrap">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
            <span className="font-semibold text-slate-700">
              {selectedListing.city} {selectedListing.district ? `(${selectedListing.district})` : ''}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{selectedListing.createdAt}</span>
          </div>

          <div className="flex items-center gap-1">
            <Eye className="w-3.5 h-3.5 text-slate-400" />
            <span>{selectedListing.viewsCount} {t('viewsCount')}</span>
          </div>
        </div>
      </div>

      {/* Attributes Table (if available) */}
      {selectedListing.attributes && Object.keys(selectedListing.attributes).length > 0 && (
        <div className="bg-white mt-2 p-4 border-y border-slate-200/80 space-y-2.5">
          <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-emerald-700" />
            <span>{t('specifications')}</span>
          </h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.entries(selectedListing.attributes).map(([key, val]) => (
              <div key={key} className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                <span className="text-slate-400 block text-[11px] mb-0.5">{key}</span>
                <span className="text-slate-800 font-bold">{val}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Description */}
      <div className="bg-white mt-2 p-4 border-y border-slate-200/80 space-y-2">
        <h3 className="font-bold text-slate-800 text-sm">{t('adDetails')}</h3>
        <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">
          {selectedListing.description}
        </p>
      </div>

      {/* Safety Notice for Sudanese context */}
      <div className="mx-4 mt-3 bg-amber-50/90 border border-amber-200/80 rounded-2xl p-3.5 flex items-start gap-3 text-xs text-amber-900 leading-relaxed shadow-xs">
        <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-amber-950 mb-0.5">{t('safetyAlertTitle')}</h4>
          <p>{t('safetyAlertMsg')}</p>
        </div>
      </div>

      {/* Seller Profile Card */}
      <div className="bg-white mx-4 mt-3 rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-emerald-800 text-white font-black flex items-center justify-center text-lg shadow-xs">
              {selectedListing.seller?.name?.slice(0, 1) || 'س'}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-slate-900 text-sm">{selectedListing.seller?.name || t('verifiedSeller')}</h4>
                {selectedListing.seller?.verified && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="flex items-center gap-1 text-amber-600 font-bold">
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                  {selectedListing.seller?.rating || '5.0'}
                </span>
                <span>• {t('memberSince')} {selectedListing.seller?.memberSince || '2026'}</span>
              </div>
              {phoneValidation.isValid && (
                <div className="text-[11px] font-mono text-emerald-800 font-bold mt-1" dir="ltr">
                  {formatDisplayPhone(phoneValidation.international)}
                </div>
              )}
            </div>
          </div>

          <div className={isRtl ? 'text-left' : 'text-right'}>
            <span className="text-[11px] text-slate-400 block">{t('activeAds')}</span>
            <span className="text-xs font-bold text-slate-800">
              {selectedListing.seller?.totalListings || 1}
            </span>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>{t('identityVerified')}</span>
          </div>
          <button className="text-emerald-800 font-bold hover:underline cursor-pointer">
            {t('viewSellerAds')}
          </button>
        </div>
      </div>

      {/* Report Ad */}
      <div className="text-center pt-4 pb-2">
        <button className="text-xs text-slate-400 hover:text-rose-600 flex items-center justify-center gap-1 mx-auto transition-colors cursor-pointer">
          <Flag className="w-3.5 h-3.5" />
          <span>{t('reportAd')}</span>
        </button>
      </div>

      {/* Bottom Sticky Action Bar: Call and WhatsApp */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 shadow-lg max-w-md mx-auto">
        <div className="flex items-center gap-2.5">
          {/* Direct Call Button */}
          <button
            onClick={handleCall}
            className="flex-1 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white py-3.5 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-900/20 active:scale-98 cursor-pointer"
          >
            <Phone className="w-4 h-4 fill-white" />
            <span>{t('directCall')}</span>
          </button>

          {/* WhatsApp Button */}
          <button
            onClick={handleWhatsApp}
            className="flex-1 bg-[#25D366] hover:bg-[#20ba59] active:bg-[#1a9a49] text-white py-3.5 px-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-green-900/20 active:scale-98 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>{t('whatsappChat')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
