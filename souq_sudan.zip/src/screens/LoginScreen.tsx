import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LogIn, 
  Lock, 
  Mail, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  ArrowRight, 
  UserPlus, 
  Database,
  Clock
} from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const { 
    signInWithSupabase, 
    supabaseConnected, 
    setIsSupabaseModalOpen,
    navigate,
    goBack 
  } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || cooldown > 0) return;

    setError('');
    setSuccess('');

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('يرجى إدخال بريدك الإلكتروني المسجل (مثال: name@example.com)');
      return;
    }

    if (!password || password.length < 6) {
      setError('كلمة المرور يجب أن تتكون من 6 خانات على الأقل');
      return;
    }

    if (!supabaseConnected) {
      setError('لم يتم ضبط مفتاح Supabase بعد. اضغط على الزر أدناه لإدخال المفتاح العام (Anon Key).');
      setIsSupabaseModalOpen(true);
      return;
    }

    setLoading(true);

    const result = await signInWithSupabase(cleanEmail, password);
    setLoading(false);

    if (result.success) {
      setSuccess('تم تسجيل الدخول بنجاح! جاري التوجيه إلى حسابك...');
      setTimeout(() => {
        navigate('profile');
      }, 900);
    } else {
      setError(result.error || 'بيانات الدخول غير صحيحة');
      if (result.error && (result.error.includes('تجاوز الحد') || result.error.includes('Rate limit'))) {
        setCooldown(30);
      }
    }
  };

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      {/* Top Breadcrumb/Back */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={goBack}
          className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-emerald-800 transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع</span>
        </button>

        <button
          onClick={() => navigate('auth_register')}
          className="text-xs font-bold text-emerald-800 hover:text-emerald-900 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200/60 transition-colors"
        >
          إنشاء حساب جديد
        </button>
      </div>

      {/* Supabase Status Banner */}
      {!supabaseConnected && (
        <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-3.5 mb-4 text-xs text-amber-900 flex items-start justify-between gap-2 shadow-xs">
          <div className="flex items-start gap-2">
            <Database className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">بانتظار ضبط مفتاح Supabase</strong>
              <p className="text-[11px] text-amber-800">
                أدخل المفتاح العام (Anon Key) لتسجيل الدخول والتحقق الفعلي عبر Supabase Auth.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSupabaseModalOpen(true)}
            className="px-2.5 py-1 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-lg text-[11px] shrink-0"
          >
            إدخال المفتاح
          </button>
        </div>
      )}

      {/* Main Login Card */}
      <div className="max-w-md mx-auto bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-800 text-white font-black text-3xl flex items-center justify-center mx-auto mb-3 shadow-md shadow-emerald-950/20">
            س
          </div>
          <h1 className="text-xl font-black text-slate-900">تسجيل الدخول</h1>
          <p className="text-xs text-slate-500 mt-1">
            سجل دخولك إلى «سوق السودان» لإدارة إعلاناتك والتواصل الفوري مع المشترين
          </p>
        </div>

        {/* Feedback messages */}
        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 mb-4 text-xs text-rose-700 font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-3.5 mb-4 text-xs text-emerald-800 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{success}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              البريد الإلكتروني المسجل *
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none dir-ltr text-right"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              البريد الإلكتروني الذي تم إنشاء الحساب به في Supabase
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              كلمة المرور *
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || cooldown > 0}
            className={`w-full py-3.5 rounded-2xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 mt-2 ${
              loading || cooldown > 0
                ? 'bg-slate-400 text-white cursor-not-allowed'
                : 'bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white shadow-emerald-900/20 cursor-pointer'
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري تسجيل الدخول...</span>
              </>
            ) : cooldown > 0 ? (
              <>
                <Clock className="w-4 h-4" />
                <span>يرجى الانتظار ({cooldown} ثانية)</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>دخول إلى حسابي</span>
              </>
            )}
          </button>
        </form>

        {/* Switch to Register */}
        <div className="mt-6 pt-4 border-t border-slate-100 text-center space-y-2">
          <p className="text-xs text-slate-500">
            ليس لديك حساب في سوق السودان؟
          </p>
          <button
            onClick={() => navigate('auth_register')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 hover:underline"
          >
            <UserPlus className="w-4 h-4" />
            <span>إنشاء حساب جديد مجاناً</span>
          </button>
        </div>

        {/* Browse as guest */}
        <div className="mt-3 text-center">
          <button
            onClick={() => navigate('home')}
            className="text-xs text-slate-400 hover:text-slate-600 font-medium"
          >
            متابعة التصفح كزائر
          </button>
        </div>
      </div>
    </div>
  );
};
