import React from 'react';
import { useApp } from '../context/AppContext';
import { Shield, FileText, CheckCircle2, ArrowRight } from 'lucide-react';

export const PrivacyPolicyScreen: React.FC = () => {
  const { goBack } = useApp();

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4 text-xs text-slate-700 leading-relaxed">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900">سياسة الخصوصية وأمان المستخدمين</h2>
            <p className="text-[10px] text-slate-400">آخر تحديث: 2026</p>
          </div>
        </div>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">1. جمع البيانات الشخصية</h3>
          <p>
            يقوم تطبيق «سوق السودان» بجمع الحد الأدنى من البيانات الضرورية لتسهيل عملية التواصل بين البائع والمشتري، وتشمل: رقم الهاتف، الاسم، المدينة، ومعلومات الإعلانات التي تنشرها.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">2. حماية بيانات التواصل والخصوصية</h3>
          <p>
            لا نقوم ببيع أو مشاركة أرقام الهواتف أو البيانات الشخصية مع أي طرف ثالث لأغراض إعلانية غير مصرح بها. تُعرض معلومات الاتصال (الهاتف، الواتساب) فقط في الإعلانات التي اخترت نشرها بإرادتك.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">3. المعاملات المالية والمصرفية</h3>
          <p>
            تطبيق «سوق السودان» منصة إعلانية وسيطة للعرض والتواصل، ولا يحتفظ بأي أرقام حسابات بنكية أو بطاقات دفع. كافة التعاملات المالية تتم بالاتفاق المباشر بين الطرفين وفق قواعد السلامة الموصى بها.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">4. أمان الحساب وتوثيقه</h3>
          <p>
            يتم توثيق الحسابات برمز تحقق نصي (SMS) لضمان مصداقية المعلنين والحد من الإعلانات الوهمية أو المضللة داخل المجتمع السوداني.
          </p>
        </section>

        <div className="pt-3">
          <button
            onClick={goBack}
            className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-2xl text-xs transition-colors"
          >
            فهمت وموافق
          </button>
        </div>
      </div>
    </div>
  );
};

export const TermsOfServiceScreen: React.FC = () => {
  const { goBack } = useApp();

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4 text-xs text-slate-700 leading-relaxed">
        <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900">شروط الاستخدام واتفاقية المنصة</h2>
            <p className="text-[10px] text-slate-400">سوق السودان للإعلانات المبوبة</p>
          </div>
        </div>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">1. طبيعة المنصة والمسؤولية</h3>
          <p>
            يعمل تطبيق «سوق السودان» كحلقة وصل تقنية مجانية بين البائع والمشتري لعرض السلع والخدمات في مختلف الولايات والمدن السودانية. التطبيق لا يملك السلع المعروضة ولا يقدم ضمانات مباشرة عليها.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">2. شروط نشر الإعلانات</h3>
          <ul className="list-disc list-inside space-y-1 text-slate-600">
            <li>يجب أن تكون السلعة المعروضة ملكاً للمعلن أو يملك تفويضاً نظامياً ببيعها.</li>
            <li>يُمنع منعاً باتاً نشر أي سلع محظورة قانوناً أو مسروقة.</li>
            <li>يجب وضع السعر الحقيقي بالجنيه السوداني ووصف السلعة بأمانة ودقة دون تضليل.</li>
            <li>يُحظر تكرار الإعلان نفسه في أكثر من قسم أو أكثر من مدينة دون مبرر.</li>
          </ul>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">3. إرشادات المعاينة والتحويلات المالية</h3>
          <p>
            نلزم جميع المستخدمين بإجراء المعاينة الميدانية وفحص السلعة (خاصة السيارات، العقارات، والأجهزة الثمينة) واستلام المستندات الرسمية قبل تسليم أي أموال نقدية أو إجراء تحويلات عبر التطبيقات البنكية (بنكك، فوري، إلخ).
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="font-bold text-slate-900 text-sm">4. حظر الحسابات المخالفة</h3>
          <p>
            تحتفظ إدارة المنصة بحق حذف أي إعلان أو إيقاف أي حساب ينتهك هذه المعايير أو تصدر ضده بلاغات احتيال متكررة وموثقة.
          </p>
        </section>

        <div className="pt-3">
          <button
            onClick={goBack}
            className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-2xl text-xs transition-colors"
          >
            الموافقة على الشروط
          </button>
        </div>
      </div>
    </div>
  );
};
