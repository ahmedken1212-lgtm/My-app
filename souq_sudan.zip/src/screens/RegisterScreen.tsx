import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CITIES } from '../data/mockData';
import { 
  UserPlus, 
  Lock, 
  Phone, 
  Mail, 
  User, 
  MapPin, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  ArrowRight, 
  LogIn, 
  ShieldCheck, 
  Database,
  Clock,
  Info
} from 'lucide-react';

export const RegisterScreen: React.FC = () => {
  const { 
    signUpWithSupabase, 
    supabaseConnected, 
    setIsSupabaseModalOpen,
    navigate,
    goBack 
  } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('912345678');
  const [password, setPassword] = useState('');
  const [selectedCity, setSelectedCity] = useState(CITIES[1].nameAr);
  const [agreeTerms, setAgreeTerms] = useState(true);

  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Handle rate limit cooldown countdown
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cooldown > 0 || loading) return;

    setError('');
    setSuccess('');

    if (!name.trim()) {
      setError('يرجى إدخال اسمك الكامل أو اسم المتجر');
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('يرجى إدخال بريد إلكتروني حقيقي وصالح لمصادقة الحساب (مثال: name@example.com)');
      return;
    }

    const cleanPhone = phone.trim().replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length < 9) {
      setError('يرجى إدخال رقم هاتف سوداني صحيح (مثال: 912345678)');
      return;
    }

    if (!password || password.length < 6) {
      setError('كلمة المرور يجب أن تتكون من 6 خانات على الأقل');
      return;
    }

    if (!agreeTerms) {
      setError('يرجى الموافقة على شروط الاستخدام وسياسة الخصوصية');
      return;
    }

    if (!supabaseConnected) {
      setError('لم يتم ضبط مفتاح Supabase بعد. اضغط على الزر أدناه لإدخال المفتاح العام (Anon Key).');
      setIsSupabaseModalOpen(true);
      return;
    }

    setLoading(true);

    const result = await signUpWithSupabase(
      cleanEmail, 
      password, 
      name.trim(), 
      cleanPhone, 
      selectedCity
    );

    setLoading(false);

    if (result.success) {
      setSuccess('تم إنشاء الحساب بنجاح في Supabase! جاري توجيهك إلى حسابك...');
      setTimeout(() => {
        navigate('profile');
      }, 1200);
    } else {
      setError(result.error || 'فشلت عملية إنشاء الحساب');
      // If error is related to rate limit, enforce a 45 second cooldown
      if (result.error && (result.error.includes('تجاوز الحد') || result.error.includes('Rate limit'))) {
        setCooldown(45);
      }
    }
  };

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      {/* Top Breadcrumb/Back */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={goBack}
          className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-emerald-800 transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع</span>
        </button>

        <button
          onClick={() => navigate('auth_login')}
          className="text-xs font-bold text-emerald-800 hover:text-emerald-900 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200/60 transition-colors"
        >
          تسجيل الدخول
        </button>
      </div>

      {/* Supabase Status Banner */}
      {!supabaseConnected && (
        <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-3.5 mb-4 text-xs text-amber-900 flex items-start justify-between gap-2 shadow-xs">
          <div className="flex items-start gap-2">
            <Database className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">بانتظار ضبط مفتاح Supabase</strong>
              <p className="text-[11px] text-amber-800">
                أدخل المفتاح العام (Anon Key) لتسجيل الحسابات وتخزينها في قاعدة البيانات.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSupabaseModalOpen(true)}
            className="px-2.5 py-1 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-lg text-[11px] shrink-0"
          >
            إدخال المفتاح
          </button>
        </div>
      )}

      {/* Main Register Card */}
      <div className="max-w-md mx-auto bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-800 text-white font-black text-3xl flex items-center justify-center mx-auto mb-3 shadow-md shadow-emerald-950/20">
            س
          </div>
          <h1 className="text-xl font-black text-slate-900">إنشاء حساب جديد</h1>
          <p className="text-xs text-slate-500 mt-1">
            انضم الآن إلى «سوق السودان» وانشر إعلاناتك بكل سهولة وأمان
          </p>
        </div>

        {/* Feedback messages */}
        {error && (
          <div className="space-y-2 mb-4">
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 text-xs text-rose-700 font-bold flex items-start gap-2 leading-relaxed">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <span>{error}</span>
            </div>

            {error.includes('Rate limit') || error.includes('تجاوز الحد') ? (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-[11px] text-amber-900 flex items-start gap-2 leading-relaxed">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold block mb-0.5">كيفية حل هذه المشكلة من لوحة Supabase:</strong>
                  <span>
                    في لوحة تحكم Supabase، اذهب إلى <strong>Authentication &gt; Providers &gt; Email</strong> وعطّل خيار <strong>Confirm email</strong>. هذا يسمح بإنشاء الحساب فوراً دون إرسال رسائل ودون الاصطدام بحد الإرسال المجاني.
                  </span>
                </div>
              </div>
            ) : null}
          </div>
        )}

        {success && (
          <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-3.5 mb-4 text-xs text-emerald-800 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{success}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              الاسم الكامل أو اسم المتجر *
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: عثمان عبد الله الفكي"
                className="w-full bg-transparent p-3 text-sm text-slate-800 focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Genuine Email */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
              <span>البريد الإلكتروني للمصادقة *</span>
              <span className="text-[10px] text-slate-400 font-normal">لحفظ حسابك في Supabase</span>
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none dir-ltr text-right"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              يُستخدم بريدك الإلكتروني لتأمين الدخول واستعادة الحساب
            </p>
          </div>

          {/* Real Phone Number (saved in user metadata) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
              <span>رقم الهاتف السوداني *</span>
              <span className="text-[10px] text-slate-400 font-normal">لإعلاناتك والواتساب</span>
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-700 px-3 py-3 text-xs font-mono font-bold flex items-center border-l border-slate-200">
                +249
              </span>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="912345678"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none dir-ltr text-right"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              يُحفظ رقم هاتفك في بيانات البائع لتسهيل التواصل المباشر مع المشترين
            </p>
          </div>

          {/* City */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              المدينة أو الولاية
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <MapPin className="w-4 h-4" />
              </span>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-transparent p-3 text-xs text-slate-800 font-medium focus:outline-none"
              >
                {CITIES.filter((c) => c.id !== 'all').map((c) => (
                  <option key={c.id} value={c.nameAr}>
                    {c.nameAr} ({c.region})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              كلمة المرور *
            </label>
            <div className="flex rounded-xl overflow-hidden border border-slate-200 bg-slate-50 focus-within:ring-2 focus-within:ring-emerald-700/30">
              <span className="bg-slate-100 text-slate-600 px-3 py-3 text-xs font-bold flex items-center border-l border-slate-200">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-transparent p-3 text-sm font-mono text-slate-800 focus:outline-none"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              يجب ألا تقل عن 6 خانات
            </p>
          </div>

          {/* Terms checkbox */}
          <label className="flex items-center gap-2 cursor-pointer select-none pt-1">
            <input
              type="checkbox"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="w-4 h-4 text-emerald-800 rounded border-slate-300 focus:ring-emerald-700 accent-emerald-800"
            />
            <span className="text-xs text-slate-600 font-medium leading-relaxed">
              أوافق على <button type="button" onClick={() => navigate('terms_of_service')} className="text-emerald-800 font-bold underline">شروط الاستخدام</button> و <button type="button" onClick={() => navigate('privacy_policy')} className="text-emerald-800 font-bold underline">سياسة الخصوصية</button>
            </span>
          </label>

          {/* Submit Button with Cooldown & Loading Protection */}
          <button
            type="submit"
            disabled={loading || cooldown > 0}
            className={`w-full py-3.5 rounded-2xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 mt-2 ${
              loading || cooldown > 0
                ? 'bg-slate-400 text-white cursor-not-allowed'
                : 'bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white shadow-emerald-900/20 cursor-pointer'
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري إنشاء الحساب في Supabase...</span>
              </>
            ) : cooldown > 0 ? (
              <>
                <Clock className="w-4 h-4" />
                <span>يرجى الانتظار ({cooldown} ثانية)</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>إنشاء الحساب الآن</span>
              </>
            )}
          </button>
        </form>

        {/* Switch to Login */}
        <div className="mt-6 pt-4 border-t border-slate-100 text-center space-y-2">
          <p className="text-xs text-slate-500">
            لديك حساب بالفعل في سوق السودان؟
          </p>
          <button
            onClick={() => navigate('auth_login')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 hover:underline"
          >
            <LogIn className="w-4 h-4" />
            <span>تسجيل الدخول إلى حسابك</span>
          </button>
        </div>
      </div>
    </div>
  );
};
