import React from 'react';
import { useApp } from '../context/AppContext';
import { ListingCard } from '../components/ListingCard';
import { EmptyState } from '../components/StateFeedback';
import { Heart, Trash2 } from 'lucide-react';

export const FavoritesScreen: React.FC = () => {
  const { allListings, favorites, navigate } = useApp();

  const favoriteListings = allListings.filter((l) => favorites.includes(l.id));

  return (
    <div className="pb-16 px-4 pt-3 bg-slate-50 min-h-screen" dir="rtl">
      {favoriteListings.length === 0 ? (
        <EmptyState
          title="قائمة المفضلة فارغة"
          description="لم تقم بإضافة أي إعلانات إلى المفضلة بعد. انقر على أيقونة القلب على أي إعلان لحفظه والرجوع إليه لاحقاً."
          actionText="تصفح أحدث الإعلانات"
          onAction={() => navigate('home')}
        />
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
            <span className="flex items-center gap-1.5 font-bold text-slate-800">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              <span>لديك {favoriteListings.length} إعلانات محفوظة</span>
            </span>
          </div>

          <div className="space-y-3">
            {favoriteListings.map((item) => (
              <ListingCard key={item.id} listing={item} layout="horizontal" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
