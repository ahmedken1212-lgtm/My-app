/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AndroidFrame } from './components/AndroidFrame';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar } from './components/BottomNavBar';
import { CityPickerModal } from './components/CityPickerModal';
import { SupabaseSetupModal } from './components/SupabaseSetupModal';

import { HomeScreen } from './screens/HomeScreen';
import { CategoriesScreen } from './screens/CategoriesScreen';
import { SearchResultsScreen } from './screens/SearchResultsScreen';
import { ListingDetailScreen } from './screens/ListingDetailScreen';
import { CreateListingScreen } from './screens/CreateListingScreen';
import { LoginScreen } from './screens/LoginScreen';
import { RegisterScreen } from './screens/RegisterScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AccountSettingsScreen } from './screens/AccountSettingsScreen';
import { FavoritesScreen } from './screens/FavoritesScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { PrivacyPolicyScreen, TermsOfServiceScreen } from './screens/PolicyScreens';

const MainScreenRouter: React.FC = () => {
  const { currentScreen } = useApp();

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen />;
      case 'categories':
        return <CategoriesScreen />;
      case 'search':
        return <SearchResultsScreen />;
      case 'listing_detail':
        return <ListingDetailScreen />;
      case 'create_listing':
        return <CreateListingScreen />;
      case 'auth_login':
        return <LoginScreen />;
      case 'auth_register':
        return <RegisterScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'account_settings':
        return <AccountSettingsScreen />;
      case 'favorites':
        return <FavoritesScreen />;
      case 'notifications':
        return <NotificationsScreen />;
      case 'settings':
        return <SettingsScreen />;
      case 'privacy_policy':
        return <PrivacyPolicyScreen />;
      case 'terms_of_service':
        return <TermsOfServiceScreen />;
      default:
        return <HomeScreen />;
    }
  };

  // On listing_detail, bottom bar is replaced by Sticky Call/WhatsApp action bar
  const showBottomNav = currentScreen !== 'listing_detail';

  return (
    <div className="flex flex-col min-h-full">
      <TopAppBar />
      <div className="flex-1">
        {renderScreen()}
      </div>
      {showBottomNav && <BottomNavBar />}
      <CityPickerModal />
      <SupabaseSetupModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AndroidFrame>
        <MainScreenRouter />
      </AndroidFrame>
    </AppProvider>
  );
}
