import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SUPABASE_URL } from '../lib/supabase';
import { 
  Database, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Key, 
  ExternalLink, 
  RefreshCw, 
  Layers, 
  Image as ImageIcon,
  ShieldCheck
} from 'lucide-react';

export const SupabaseSetupModal: React.FC = () => {
  const { 
    isSupabaseModalOpen, 
    setIsSupabaseModalOpen, 
    supabaseAnonKey, 
    saveSupabaseAnonKey,
    supabaseConnected,
    refreshListings,
    isDbLoading,
    dbError,
    allListings
  } = useApp();

  const [inputKey, setInputKey] = useState(supabaseAnonKey);
  const [testStatus, setTestStatus] = useState<string | null>(null);

  if (!isSupabaseModalOpen) return null;

  const handleSave = () => {
    saveSupabaseAnonKey(inputKey.trim());
    setTestStatus('تم حفظ المفتاح وتحديث الاتصال!');
    setTimeout(() => {
      refreshListings();
    }, 300);
  };

  const handleTest = async () => {
    setTestStatus('جاري فحص الاتصال بقاعدة بيانات Supabase...');
    await refreshListings();
    setTestStatus('تم فحص الاتصال وجلب الإعلانات من جدول public.listings');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div 
        className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[92vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 bg-emerald-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-emerald-300">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm">ربط وإعدادات مشروع Supabase</h3>
              <p className="text-[11px] text-emerald-200">سوق السودان - إدارة الاتصال بقاعدة البيانات</p>
            </div>
          </div>
          <button
            onClick={() => setIsSupabaseModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 overflow-y-auto text-xs text-slate-700">
          {/* Status Badge */}
          <div className={`p-3.5 rounded-2xl border flex items-start gap-2.5 ${
            supabaseConnected
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            {supabaseConnected ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div>
              <strong className="block font-bold mb-0.5 text-sm">
                {supabaseConnected ? 'المشروع متصل بـ Supabase بنجاح' : 'في انتظار المفتاح العام (Publishable Anon Key)'}
              </strong>
              <p className="text-[11px] leading-relaxed">
                {supabaseConnected
                  ? `الاتصال مفعل، يتم جلب وحفظ الإعلانات الحقيقية في جدول listings وتخزين الصور في listing-images.`
                  : 'أدخل المفتاح العام (anon key) من لوحة تحكم Supabase لتفعيل القراءة والكتابة السحابية.'}
              </p>
            </div>
          </div>

          {/* Project Details */}
          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200/80 space-y-2">
            <div className="flex justify-between items-center py-1 border-b border-slate-200/60">
              <span className="text-slate-500 font-semibold">رابط المشروع (Project URL):</span>
              <span className="font-mono text-emerald-900 font-bold dir-ltr select-all text-[11px]">
                {SUPABASE_URL}
              </span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-200/60">
              <span className="text-slate-500 font-semibold">جدول الإعلانات:</span>
              <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-800">
                public.listings
              </span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="text-slate-500 font-semibold">مخزن الصور:</span>
              <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-800">
                listing-images
              </span>
            </div>
          </div>

          {/* Anon Key Input */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Key className="w-4 h-4 text-emerald-700" />
                <span>المفتاح العام (anon public key):</span>
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                لا تضع أبداً service_role key
              </span>
            </label>
            <input
              type="text"
              value={inputKey}
              onChange={(e) => setInputKey(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
            />
            <p className="text-[10px] text-slate-400 leading-relaxed">
              يمكنك الحصول على المفتاح من لوحة تحكم Supabase الخاصة بمشروعك: Settings &gt; API &gt; Project API keys &gt; `anon public`.
            </p>
          </div>

          {/* Test Status Feedback */}
          {testStatus && (
            <div className="bg-slate-100 p-2.5 rounded-xl text-center text-xs text-slate-700 font-medium">
              {testStatus}
            </div>
          )}

          {dbError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 p-2.5 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{dbError}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
          <button
            onClick={handleTest}
            disabled={isDbLoading}
            className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold rounded-xl transition-colors shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isDbLoading ? 'animate-spin' : ''}`} />
            <span>اختبار الاتصال</span>
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white font-bold rounded-xl transition-colors shadow-xs text-center"
          >
            حفظ المفتاح وتفعيل الربط
          </button>
        </div>
      </div>
    </div>
  );
};
