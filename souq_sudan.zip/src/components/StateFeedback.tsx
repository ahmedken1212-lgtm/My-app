import React from 'react';
import { RefreshCw, SearchX, AlertTriangle, ArrowRight } from 'lucide-react';

interface LoadingSkeletonProps {
  count?: number;
}

export const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({ count = 4 }) => {
  return (
    <div className="space-y-4 p-4 animate-pulse">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white rounded-2xl p-3 shadow-xs border border-slate-100 flex gap-3">
          <div className="w-28 h-28 bg-slate-200 rounded-xl shrink-0" />
          <div className="flex-1 space-y-2 py-1">
            <div className="h-4 bg-slate-200 rounded w-5/6" />
            <div className="h-3 bg-slate-200 rounded w-1/2" />
            <div className="h-5 bg-emerald-100 rounded w-1/3 mt-2" />
            <div className="flex justify-between items-center pt-2">
              <div className="h-3 bg-slate-200 rounded w-1/4" />
              <div className="h-3 bg-slate-200 rounded w-1/6" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title = 'لا توجد إعلانات مطابقة',
  description = 'جرب البحث بكلمات أخرى أو قم بتغيير الفلاتر والمدينة المختارة.',
  actionText = 'إعادة ضبط الفلاتر',
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center my-6">
      <div className="w-20 h-20 bg-emerald-50 text-emerald-700 rounded-full flex items-center justify-center mb-4 shadow-inner">
        <SearchX className="w-10 h-10" />
      </div>
      <h3 className="text-lg font-bold text-slate-800 mb-1">{title}</h3>
      <p className="text-sm text-slate-500 max-w-xs mb-5 leading-relaxed">{description}</p>
      {onAction && (
        <button
          onClick={onAction}
          className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white rounded-xl text-sm font-semibold transition-colors shadow-xs flex items-center gap-2 cursor-pointer"
        >
          <span>{actionText}</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      )}
    </div>
  );
};

interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  title = 'حدث خطأ في تحميل البيانات',
  description = 'تعذر الاتصال بقاعدة البيانات. يرجى التحقق من اتصال الشبكة والمحاولة مرة أخرى.',
  onRetry,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center my-6">
      <div className="w-20 h-20 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mb-4">
        <AlertTriangle className="w-10 h-10" />
      </div>
      <h3 className="text-lg font-bold text-slate-800 mb-1">{title}</h3>
      <p className="text-sm text-slate-500 max-w-xs mb-5 leading-relaxed">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-900 active:bg-slate-950 text-white rounded-xl text-sm font-semibold transition-colors shadow-xs flex items-center gap-2 cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" />
          <span>إعادة المحاولة</span>
        </button>
      )}
    </div>
  );
};
