import React from 'react';
import { useApp } from '../context/AppContext';
import { CITIES } from '../data/mockData';
import { UserAvatar } from './UserAvatar';
import { 
  MapPin, 
  Bell, 
  ArrowRight, 
  ArrowLeft,
  SlidersHorizontal, 
  Share2, 
  Search,
  ChevronDown,
  User
} from 'lucide-react';

export const TopAppBar: React.FC = () => {
  const { 
    currentScreen, 
    goBack, 
    navigate, 
    selectedCity, 
    setIsCityModalOpen, 
    unreadCount,
    selectedListing,
    resetFilters,
    isLoggedIn,
    user,
    t,
    isRtl
  } = useApp();

  const currentCityObj = CITIES.find((c) => c.id === selectedCity) || CITIES[0];
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  const handleShare = () => {
    if (navigator.share && selectedListing) {
      navigator.share({
        title: selectedListing.title,
        text: `${selectedListing.title} - ${t('appName')}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      alert(t('copyLinkSuccess'));
    }
  };

  // Home Screen Top App Bar
  if (currentScreen === 'home') {
    return (
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 px-4 py-2.5 flex items-center justify-between shadow-2xs" dir={isRtl ? 'rtl' : 'ltr'}>
        {/* Brand Identity */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-black text-lg shadow-xs shrink-0">
            س
          </div>
          <div className="min-w-0">
            <h1 className="font-black text-emerald-900 text-lg leading-tight tracking-tight truncate">
              {t('appName')}
            </h1>
            <p className="text-[10px] text-slate-400 font-medium truncate hidden sm:block">
              {t('appTagline')}
            </p>
          </div>
        </div>

        {/* Account and Notifications */}
        <div className="flex items-center gap-2 shrink-0">
          {/* My Account Button */}
          <button
            onClick={() => navigate(isLoggedIn ? 'profile' : 'auth_login')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border cursor-pointer ${
              isLoggedIn
                ? 'bg-emerald-800 text-white border-emerald-900 shadow-xs hover:bg-emerald-900'
                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200 shadow-2xs'
            }`}
            title={isLoggedIn ? t('myAccount') : t('login')}
          >
            {isLoggedIn ? (
              <UserAvatar
                name={user?.name}
                avatarUrl={user?.avatarUrl}
                size="xs"
                fallbackType="letter_s"
                className="w-4.5 h-4.5 text-[9px] rounded-full ring-1 ring-white/30"
              />
            ) : (
              <User className="w-3.5 h-3.5 text-emerald-700" />
            )}
            <span className="truncate max-w-[85px]">
              {isLoggedIn ? (user?.name?.split(' ')[0] || t('myAccount')) : t('myAccount')}
            </span>
            {isLoggedIn && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300" />
            )}
          </button>

          {/* Notifications Button */}
          <button
            onClick={() => navigate('notifications')}
            className="relative w-8.5 h-8.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={t('navNotifications')}
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-rose-600 rounded-full ring-2 ring-white animate-pulse" />
            )}
          </button>
        </div>
      </header>
    );
  }

  // Listing Detail Screen Top App Bar
  if (currentScreen === 'listing_detail') {
    return (
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 px-3 py-2.5 flex items-center justify-between" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="flex items-center gap-2">
          <button
            onClick={goBack}
            className="w-9 h-9 rounded-full hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={t('back')}
          >
            <BackIcon className="w-5 h-5" />
          </button>
          <span className="font-bold text-slate-800 text-sm truncate max-w-[200px]">
            {t('adDetails')}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleShare}
            className="w-9 h-9 rounded-full hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </header>
    );
  }

  // Get screen titles
  const getScreenTitle = () => {
    switch (currentScreen) {
      case 'categories':
        return t('navCategories');
      case 'search':
        return t('searchFilters');
      case 'create_listing':
        return t('createNewAd');
      case 'auth_login':
        return t('login');
      case 'auth_register':
        return t('register');
      case 'profile':
        return t('myAccount');
      case 'account_settings':
        return t('accountSettingsTitle');
      case 'favorites':
        return t('navFavorites');
      case 'notifications':
        return t('navNotifications');
      case 'settings':
        return t('settingsTitle');
      case 'privacy_policy':
        return t('privacyPolicy');
      case 'terms_of_service':
        return t('termsOfService');
      default:
        return t('appName');
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 px-3 py-2.5 flex items-center justify-between shadow-2xs" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="flex items-center gap-2">
        <button
          onClick={goBack}
          className="w-9 h-9 rounded-full hover:bg-slate-100 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          aria-label={t('back')}
        >
          <BackIcon className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-slate-800 text-base">{getScreenTitle()}</h2>
      </div>

      <div className="flex items-center gap-1.5">
        {currentScreen === 'search' && (
          <button
            onClick={resetFilters}
            className="text-xs text-emerald-800 hover:text-emerald-900 font-semibold px-2 py-1 rounded-lg hover:bg-emerald-50 transition-colors cursor-pointer"
          >
            {t('resetFilters')}
          </button>
        )}
        {currentScreen !== 'search' && (
          <button
            onClick={() => navigate('search')}
            className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={t('searchBtn')}
          >
            <Search className="w-4 h-4" />
          </button>
        )}
        {currentScreen !== 'profile' && currentScreen !== 'account_settings' && currentScreen !== 'auth_login' && currentScreen !== 'auth_register' && (
          <button
            onClick={() => navigate(isLoggedIn ? 'profile' : 'auth_login')}
            className="w-8 h-8 rounded-full hover:bg-emerald-50 text-emerald-800 flex items-center justify-center transition-colors border border-emerald-200/60 overflow-hidden cursor-pointer"
            title={t('myAccount')}
            aria-label={t('myAccount')}
          >
            {isLoggedIn ? (
              <UserAvatar
                name={user?.name}
                avatarUrl={user?.avatarUrl}
                size="xs"
                fallbackType="letter_s"
                className="w-6 h-6 text-[10px] rounded-full"
              />
            ) : (
              <User className="w-4 h-4" />
            )}
          </button>
        )}
      </div>
    </header>
  );
};
