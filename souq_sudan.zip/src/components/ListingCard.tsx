import React from 'react';
import { Listing } from '../types';
import { useApp } from '../context/AppContext';
import { MapPin, Clock, Heart, Sparkles, CheckCircle2 } from 'lucide-react';

interface ListingCardProps {
  listing: Listing;
  layout?: 'grid' | 'horizontal';
}

export const ListingCard: React.FC<ListingCardProps> = ({ listing, layout = 'horizontal' }) => {
  const { navigate, isFavorite, toggleFavorite } = useApp();
  const favorite = isFavorite(listing.id);

  // Format price in Sudanese Pounds (SDG)
  const formattedPrice = new Intl.NumberFormat('ar-SD').format(listing.price);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(listing.id);
  };

  if (layout === 'grid') {
    return (
      <div
        onClick={() => navigate('listing_detail', listing)}
        className="bg-white rounded-2xl overflow-hidden border border-slate-200/80 hover:border-emerald-700/40 hover:shadow-md transition-all cursor-pointer flex flex-col group"
      >
        {/* Image Container */}
        <div className="relative aspect-4/3 w-full bg-slate-100 overflow-hidden">
          <img
            src={listing.images[0]}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />

          {listing.featured && (
            <span className="absolute top-2.5 right-2.5 bg-emerald-800 text-white text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3 text-amber-300" />
              مميز
            </span>
          )}

          <button
            onClick={handleFavoriteClick}
            aria-label="إضافة للمفضلة"
            className="absolute top-2.5 left-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-slate-700 hover:text-rose-600 hover:bg-white transition-all shadow-xs"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${
                favorite ? 'fill-rose-500 text-rose-500' : 'text-slate-600'
              }`}
            />
          </button>

          {listing.images.length > 1 && (
            <span className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[10px] px-1.5 py-0.5 rounded-md font-sans">
              +{listing.images.length - 1} صور
            </span>
          )}
        </div>

        {/* Content */}
        <div className="p-3 flex flex-col flex-1 justify-between">
          <div>
            <h4 className="font-bold text-slate-800 text-sm line-clamp-2 leading-snug group-hover:text-emerald-800 transition-colors">
              {listing.title}
            </h4>

            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-base font-extrabold text-emerald-800 tracking-tight">
                {formattedPrice}
              </span>
              <span className="text-xs font-semibold text-emerald-700">ج.س</span>
              {listing.isNegotiable && (
                <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-sm mr-1">
                  قابل للتفاوض
                </span>
              )}
            </div>
          </div>

          <div className="pt-2.5 mt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <div className="flex items-center gap-1 truncate max-w-[65%]">
              <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
              <span className="truncate">{listing.city}</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-slate-400">
              <Clock className="w-3 h-3" />
              <span>{listing.createdAt}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Horizontal card (Standard Haraj-inspired mobile list view)
  return (
    <div
      onClick={() => navigate('listing_detail', listing)}
      className="bg-white rounded-2xl p-2.5 border border-slate-200/80 hover:border-emerald-700/40 hover:shadow-xs transition-all cursor-pointer flex gap-3 group relative"
    >
      {/* Thumbnail */}
      <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-xl bg-slate-100 overflow-hidden shrink-0">
        <img
          src={listing.images[0]}
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {listing.featured && (
          <span className="absolute top-1.5 right-1.5 bg-emerald-800 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5 shadow-xs">
            <Sparkles className="w-2.5 h-2.5 text-amber-300" />
            مميز
          </span>
        )}

        {listing.images.length > 1 && (
          <span className="absolute bottom-1.5 left-1.5 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded-md font-sans">
            +{listing.images.length - 1}
          </span>
        )}
      </div>

      {/* Info */}
      <div className="flex flex-col justify-between flex-1 py-0.5">
        <div>
          <div className="flex items-start justify-between gap-1">
            <h4 className="font-bold text-slate-800 text-sm line-clamp-2 leading-snug group-hover:text-emerald-800 transition-colors">
              {listing.title}
            </h4>
            <button
              onClick={handleFavoriteClick}
              aria-label="إضافة للمفضلة"
              className="w-7 h-7 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-rose-500 shrink-0 transition-colors"
            >
              <Heart
                className={`w-4 h-4 ${
                  favorite ? 'fill-rose-500 text-rose-500' : 'text-slate-400'
                }`}
              />
            </button>
          </div>

          <div className="mt-1.5 flex items-baseline gap-1.5 flex-wrap">
            <span className="text-base font-extrabold text-emerald-800 tracking-tight">
              {formattedPrice}
            </span>
            <span className="text-xs font-bold text-emerald-700">جنيه سوداني</span>
            {listing.isNegotiable && (
              <span className="text-[10px] text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded-full font-medium">
                قابل للتفاوض
              </span>
            )}
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between text-xs text-slate-500 border-t border-slate-50 mt-1">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="font-medium text-slate-700">
              {listing.city} {listing.district ? `• ${listing.district}` : ''}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {listing.seller.verified && (
              <span className="flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full">
                <CheckCircle2 className="w-2.5 h-2.5" />
                موثوق
              </span>
            )}
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {listing.createdAt}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
