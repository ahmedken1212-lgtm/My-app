import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Wifi, 
  Battery, 
  Smartphone, 
  Tablet, 
  Monitor, 
  RefreshCw, 
  ArrowRight, 
  Circle, 
  Square, 
  Triangle,
  Database,
  Globe
} from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  const { 
    deviceMode, 
    setDeviceMode, 
    simulatedState, 
    setSimulatedState,
    goBack,
    currentScreen,
    navigate,
    supabaseConnected,
    setIsSupabaseModalOpen,
    language,
    setLanguage,
    t,
    isRtl
  } = useApp();

  const [currentTime, setCurrentTime] = useState('10:45');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center p-2 sm:p-4 text-slate-100 font-['Cairo',sans-serif]">
      {/* Top Testing & Control Bar */}
      <header className="w-full max-w-4xl bg-slate-800/80 backdrop-blur-md border border-slate-700/80 rounded-2xl p-2.5 mb-3 flex flex-wrap items-center justify-between gap-2 shadow-lg" dir="rtl">
        {/* Left: Device Switcher */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-400 font-bold ml-1 hidden sm:inline">الجهاز:</span>
          <button
            onClick={() => setDeviceMode('mobile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              deviceMode === 'mobile'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>هاتف (Pixel 8)</span>
          </button>

          <button
            onClick={() => setDeviceMode('tablet')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              deviceMode === 'tablet'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span>لوحي (Tablet)</span>
          </button>

          <button
            onClick={() => setDeviceMode('full')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              deviceMode === 'full'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-700/60'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>شاشة كاملة</span>
          </button>
        </div>

        {/* Center: State Testing Switches (Loading, Empty, Error, Normal) */}
        <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-xl border border-slate-700/60">
          <span className="text-[11px] text-slate-400 px-1.5 font-bold hidden md:inline">الحالة:</span>
          {(['normal', 'loading', 'empty', 'error'] as const).map((st) => {
            const labels = {
              normal: 'طبيعي',
              loading: 'تحميل',
              empty: 'فارغ',
              error: 'خطأ',
            };
            return (
              <button
                key={st}
                onClick={() => setSimulatedState(st)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  simulatedState === st
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {labels[st]}
              </button>
            );
          })}
        </div>

        {/* Right: Kotlin & Supabase Status Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsSupabaseModalOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
              supabaseConnected
                ? 'bg-emerald-950/80 border-emerald-600/60 text-emerald-300 hover:bg-emerald-900'
                : 'bg-amber-950/70 border-amber-600/50 text-amber-300 hover:bg-amber-900'
            }`}
            title="إعدادات وحالة اتصال Supabase"
          >
            <Database className="w-3.5 h-3.5" />
            <span>{supabaseConnected ? 'Supabase متصل' : 'ضبط Supabase'}</span>
            <span className={`w-2 h-2 rounded-full ${supabaseConnected ? 'bg-emerald-400' : 'bg-amber-400'}`} />
          </button>

          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-800/90 hover:bg-emerald-700 active:bg-emerald-600 text-emerald-100 rounded-xl text-xs font-bold transition-colors border border-emerald-600/40 cursor-pointer"
            title="تغيير لغة العرض / Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-300" />
            <span>{language === 'ar' ? 'English' : 'العربية'}</span>
          </button>
        </div>
      </header>

      {/* Device Frame Wrapper */}
      <div
        className={`w-full transition-all duration-300 flex justify-center ${
          deviceMode === 'mobile'
            ? 'max-w-[420px]'
            : deviceMode === 'tablet'
            ? 'max-w-[768px]'
            : 'max-w-4xl'
        }`}
      >
        <div
          className={`w-full bg-slate-100 text-slate-900 overflow-hidden flex flex-col shadow-2xl relative transition-all ${
            deviceMode === 'full'
              ? 'rounded-2xl border border-slate-700 min-h-[92vh]'
              : 'rounded-[44px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] min-h-[880px]'
          }`}
          dir="rtl"
        >
          {/* Android Punch-hole Camera (in mobile/tablet mode) */}
          {deviceMode !== 'full' && (
            <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-slate-900 border border-slate-700/60 z-50 pointer-events-none" />
          )}

          {/* Android Status Bar */}
          <div className="bg-slate-900 text-white px-6 py-2 flex items-center justify-between text-xs font-medium select-none z-40 shrink-0">
            {/* Clock */}
            <span className="font-bold tracking-wider">{currentTime}</span>

            {/* Status Icons */}
            <div className="flex items-center gap-2 text-slate-300">
              <span className="text-[10px] font-bold bg-slate-800 px-1.5 py-0.2 rounded-sm text-slate-200">
                5G
              </span>
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-1">
                <span className="text-[11px] font-sans">94%</span>
                <Battery className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Screen Content */}
          <main className="flex-1 overflow-y-auto bg-slate-50 flex flex-col">
            {children}
          </main>

          {/* Android Bottom Navigation Bar (Gesture Pill & Back/Home/Recents buttons) */}
          <div className="bg-slate-900 py-2 px-6 flex items-center justify-around select-none shrink-0 z-40 border-t border-slate-800">
            {/* Back Button */}
            <button
              onClick={goBack}
              disabled={currentScreen === 'home'}
              className={`p-1.5 rounded-full transition-colors ${
                currentScreen === 'home'
                  ? 'text-slate-600 cursor-not-allowed'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="رجوع"
              aria-label="Android Back"
            >
              <Triangle className="w-3.5 h-3.5 rotate-90 fill-current" />
            </button>

            {/* Home Button / Gesture Pill */}
            <button
              onClick={() => navigate('home')}
              className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              title="الصفحة الرئيسية"
              aria-label="Android Home"
            >
              <Circle className="w-4 h-4 fill-current" />
            </button>

            {/* Recents Button */}
            <button
              onClick={() => setDeviceMode(deviceMode === 'mobile' ? 'tablet' : 'mobile')}
              className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              title="تبديل العرض"
              aria-label="Android Recents"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
