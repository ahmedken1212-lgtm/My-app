import React, { useState } from 'react';
import { User } from 'lucide-react';

interface UserAvatarProps {
  name?: string;
  avatarUrl?: string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  fallbackType?: 'letter_s' | 'initial' | 'icon';
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  name,
  avatarUrl,
  size = 'md',
  className = '',
  fallbackType = 'letter_s',
}) => {
  const [imageError, setImageError] = useState(false);

  // Size configurations
  const sizeClasses = {
    xs: 'w-6 h-6 text-xs rounded-lg',
    sm: 'w-8 h-8 text-sm rounded-xl',
    md: 'w-10 h-10 text-base rounded-xl',
    lg: 'w-14 h-14 text-2xl rounded-2xl',
    xl: 'w-20 h-20 text-3xl rounded-3xl',
  };

  const iconSizes = {
    xs: 'w-3.5 h-3.5',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-7 h-7',
    xl: 'w-10 h-10',
  };

  const hasValidUrl = Boolean(
    avatarUrl && 
    typeof avatarUrl === 'string' && 
    avatarUrl.trim() !== '' && 
    !avatarUrl.includes('placeholder') &&
    !avatarUrl.includes('dummy')
  );

  // If a real verified user avatar URL exists and hasn't errored
  if (hasValidUrl && !imageError) {
    return (
      <img
        src={avatarUrl!.trim()}
        alt={name || 'صورة المستخدم'}
        onError={() => setImageError(true)}
        className={`${sizeClasses[size]} object-cover ring-2 ring-emerald-700/20 shadow-xs ${className}`}
      />
    );
  }

  // Fallback representation: Uniform, elegant Sudan Market avatar
  // Defaults to the iconic Arabic letter 'س' (سوق السودان) or user initial
  const renderContent = () => {
    if (fallbackType === 'initial' && name && name.trim().length > 0) {
      return name.trim().charAt(0);
    }
    if (fallbackType === 'icon') {
      return <User className={`${iconSizes[size]} text-emerald-100`} />;
    }
    // Default: 'س' for سوق السودان
    return 'س';
  };

  return (
    <div
      className={`${sizeClasses[size]} bg-gradient-to-br from-emerald-800 via-emerald-850 to-emerald-950 text-white font-black flex items-center justify-center shadow-xs ring-2 ring-emerald-700/20 select-none ${className}`}
      title={name || 'سوق السودان'}
    >
      {renderContent()}
    </div>
  );
};
