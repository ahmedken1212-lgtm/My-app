import React from 'react';
import { useApp } from '../context/AppContext';
import { Screen } from '../types';
import { 
  Home, 
  Grid, 
  Plus, 
  Heart, 
  User 
} from 'lucide-react';

export const BottomNavBar: React.FC = () => {
  const { currentScreen, navigate, favorites, t } = useApp();

  // Standard Material 3 bottom navigation:
  const navItems = [
    {
      id: 'home' as Screen,
      label: t('navHome'),
      icon: Home,
    },
    {
      id: 'categories' as Screen,
      label: t('navCategories'),
      icon: Grid,
    },
    {
      id: 'create_listing' as Screen,
      label: t('navCreate'),
      icon: Plus,
      isSpecial: true,
    },
    {
      id: 'favorites' as Screen,
      label: t('navFavorites'),
      icon: Heart,
      badge: favorites.length > 0 ? favorites.length : undefined,
    },
    {
      id: 'profile' as Screen,
      label: t('navProfile'),
      icon: User,
    },
  ];

  return (
    <nav className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-1.5 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id;
          const Icon = item.icon;

          if (item.isSpecial) {
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className="flex flex-col items-center justify-center -mt-5 group"
                aria-label="أضف إعلان جديد"
              >
                <div className="w-13 h-13 rounded-2xl bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white flex items-center justify-center shadow-lg shadow-emerald-900/30 ring-4 ring-white transition-all transform group-hover:scale-105 active:scale-95">
                  <Plus className="w-6 h-6 stroke-[2.5]" />
                </div>
                <span className="text-[11px] font-bold text-emerald-850 mt-1">
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className="flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all relative"
            >
              <div
                className={`w-10 h-6.5 rounded-full flex items-center justify-center transition-all ${
                  isActive
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                {item.badge !== undefined && (
                  <span className="absolute top-0.5 right-2 bg-emerald-700 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white">
                    {item.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[11px] mt-0.5 transition-colors ${
                  isActive
                    ? 'font-bold text-emerald-800'
                    : 'font-medium text-slate-500'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
