import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CITIES } from '../data/mockData';
import { MapPin, X, Check, Search } from 'lucide-react';

export const CityPickerModal: React.FC = () => {
  const { isCityModalOpen, setIsCityModalOpen, selectedCity, setSelectedCity, setFilters } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  if (!isCityModalOpen) return null;

  const filteredCities = CITIES.filter(
    (c) =>
      c.nameAr.includes(searchQuery.trim()) ||
      c.region.includes(searchQuery.trim())
  );

  const handleSelectCity = (cityId: string) => {
    setSelectedCity(cityId);
    setFilters((prev) => ({ ...prev, city: cityId }));
    setIsCityModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-slate-100"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">اختر المدينة أو الولاية</h3>
              <p className="text-xs text-slate-500">لتحديد وتصفية العروض المتاحة بالقرب منك</p>
            </div>
          </div>
          <button
            onClick={() => setIsCityModalOpen(false)}
            className="w-8 h-8 rounded-full bg-white hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-slate-100 bg-white">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مدينة أو ولاية سودانية..."
              className="w-full bg-slate-100 text-slate-800 text-sm rounded-xl pr-10 pl-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* City List */}
        <div className="overflow-y-auto p-2 divide-y divide-slate-100 flex-1">
          {filteredCities.map((city) => {
            const isSelected = selectedCity === city.id;
            return (
              <button
                key={city.id}
                onClick={() => handleSelectCity(city.id)}
                className={`w-full flex items-center justify-between p-3.5 text-right rounded-xl transition-all ${
                  isSelected
                    ? 'bg-emerald-50 text-emerald-900 font-bold'
                    : 'hover:bg-slate-50 text-slate-700 font-medium'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      isSelected ? 'bg-emerald-700 ring-4 ring-emerald-100' : 'bg-slate-300'
                    }`}
                  />
                  <div>
                    <div className="text-sm">{city.nameAr}</div>
                    <div className="text-xs text-slate-400 font-normal">{city.region}</div>
                  </div>
                </div>
                {isSelected && <Check className="w-5 h-5 text-emerald-700" />}
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-500">
            يمكنك دائماً تغيير المدينة لاحقاً من الشريط العلوي للتطبيق
          </p>
        </div>
      </div>
    </div>
  );
};
