export type Screen =
  | 'home'
  | 'categories'
  | 'search'
  | 'listing_detail'
  | 'create_listing'
  | 'auth_login'
  | 'auth_register'
  | 'profile'
  | 'account_settings'
  | 'favorites'
  | 'notifications'
  | 'settings'
  | 'privacy_policy'
  | 'terms_of_service';

export interface Category {
  id: string;
  nameAr: string;
  nameEn: string;
  iconName: string;
  color: string;
  subcategories: string[];
  listingsCount: number;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number; // In SDG (Sudanese Pounds)
  isNegotiable: boolean;
  categoryId: string;
  subCategory?: string;
  city: string;
  district?: string;
  images: string[];
  createdAt: string;
  featured?: boolean;
  viewsCount: number;
  seller: {
    id: string;
    name: string;
    phone: string;
    whatsapp: string;
    verified: boolean;
    rating: number;
    memberSince: string;
    totalListings: number;
  };
  attributes?: Record<string, string>;
}

export interface CityOption {
  id: string;
  nameAr: string;
  region: string;
}

export interface FilterState {
  query: string;
  categoryId: string;
  city: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy: 'latest' | 'price_asc' | 'price_desc';
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  type: 'system' | 'price_drop' | 'listing_inquiry';
  targetListingId?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  phone: string;
  city: string;
  avatarUrl?: string;
  verified: boolean;
  joinDate: string;
}
